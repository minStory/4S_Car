
$(function(){

    var carSell = $(".car_sell");

    var carBuy = $(".car_sell");

    var myPage = $(".car_sell");

    var comunity = $(".car_sell");
    
    var gongji = $(".gongju");


    var menual_1 = $("lnb1");

    var menual_2 = $("lnb2");

    var menual_3 = $("lnb3");

    var menual_4 = $("lnb4");

    var menual_5 = $("lnb5");
   
 
   
        $(".scroll_top").click(function(){
            $("html").animate({ scrollTop: 0 });
        })
        
   });
   
   
   
$(document).ready(function() {

    $.ajax({
        type: "POST",
        url: "check_login_status",
        success: function(response) {
            if (response.loggedIn == 1) {
            
                // 유저 로그인 상태일 경우
                $('.login_main').hide(); // 로그인 버튼 숨기기
                $('#admin_btn').hide(); // 관리자 로그인 버튼 숨기기
                $('.logout').show();
                $('#user_name').html('<a href="mypage">' + response.username + '</a> 님');
                $('#user_name').show();
                
                // 사용자 번호도 함께 받아오기
                var userno = response.userno;
            } else if(response.loggedIn == 0){
            
            	// 관리자 로그인 상태일 경우
                $('.login_main').hide();    // 로그인 버튼 숨기기
                $('#admin_btn').hide();     // 관리자 로그인 버튼 숨기기
                $('#admin_page_btn').show(); // 관리자 페이지 버튼 보이기
                $('.logout').show();
                $('#user_name').html('<a href="admin_main">' + response.adminname + '</a> 님');
                $('#user_name').show();
                
                // 사용자 번호도 함께 받아오기
                var adminno = response.adminno;
            } else {
            	
            	$('#my_page').click(function() {
            		alert("로그인 후 이용하실 수 있습니다.");
            		location.href='user_login';
            	})
            	$('#myfavorite_list').click(function() {
            		alert("로그인 후 이용하실 수 있습니다.");
            		$('#myfavorite_list').attr('href', "user_login");
            	})
            	$('#my_review').click(function() {
            		alert("로그인 후 이용하실 수 있습니다.");
            		$('#my_review').attr('href', "user_login");
            	})
            	$('#mycar_info').click(function() {
            		alert("로그인 후 이용하실 수 있습니다.");
            		$('#mycar_info').attr('href', "user_login");
            	})
            	$('#mypage').click(function() {
            		alert("로그인 후 이용하실 수 있습니다.");
            		$('#mypage').attr('href', "user_login");
            	})
            	$('#mycar_regist').click(function() {
            		alert("로그인 후 이용하실 수 있습니다.");
            		$('#mycar_regist').attr('href', "user_login");
            	})
            	$('#validate').click(function() {
            		alert("로그인 후 이용하실 수 있습니다.");
            		$('#validate').attr('href', "user_login");
            	})
            	$('#mycar_buy_history').click(function() {
            		alert("로그인 후 이용하실 수 있습니다.");
            		$('#mycar_buy_history').attr('href', "user_login");
            	})
            	$('#my_mileage_history').click(function() {
            		alert("로그인 후 이용하실 수 있습니다.");
            		$('#my_mileage_history').attr('href', "user_login");
            	})
            	return false;
            }
        }
    });
    
        // 로그아웃 버튼 클릭 시
        $(document).on('click', '#logout_btn', function(e) {
            e.preventDefault(); // 기본 동작 중단

            $.ajax({
                type: "GET",
                url: "logout", // 로그아웃 요청을 보낼 URL
                success: function(response) {
                	alert('로그아웃 했습니다.');
                    window.location.reload(true);
                }
            });
        });
    
});