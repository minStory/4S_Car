package com.car.model;

public class MileageDTO {
	private String mileage_user_no;
	private String mileage_date;
	private String mileage_cont;
	private String mileage_type;
	private int mileage_amount;
	private int mileage_status;
	private String mileage_grade;

	public String getMileage_user_no() {
		return mileage_user_no;
	}

	public void setMileage_user_no(String mileage_user_no) {
		this.mileage_user_no = mileage_user_no;
	}

	public String getMileage_date() {
		return mileage_date;
	}

	public void setMileage_date(String mileage_date) {
		this.mileage_date = mileage_date;
	}

	public String getMileage_cont() {
		return mileage_cont;
	}

	public void setMileage_cont(String mileage_cont) {
		this.mileage_cont = mileage_cont;
	}

	public String getMileage_type() {
		return mileage_type;
	}

	public void setMileage_type(String mileage_type) {
		this.mileage_type = mileage_type;
	}

	public int getMileage_amount() {
		return mileage_amount;
	}

	public void setMileage_amount(int mileage_amount) {
		this.mileage_amount = mileage_amount;
	}

	public int getMileage_status() {
		return mileage_status;
	}

	public void setMileage_status(int mileage_status) {
		this.mileage_status = mileage_status;
	}

	public String getMileage_grade() {
		return mileage_grade;
	}

	public void setMileage_grade(String mileage_grade) {
		this.mileage_grade = mileage_grade;
	}

}
