package com.car.action.boards;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.model.CommunityBoardDTO;
import com.car.model.TotalDAO;

public class CommunityBoardListAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		TotalDAO dao = TotalDAO.getInstance();
		
		int community_rowsize = 10;

		int community_block = 3;

		int community_count = 0;

		int community_allPage = 0;

		int community_page = 0;

		if (request.getParameter("community_page") != null) {
			community_page = Integer.parseInt(request.getParameter("community_page").trim());

		} else {
			community_page = 1;
			community_count = dao.countCommunityBoardList(); 
		}

		int community_startNo = (community_page * community_rowsize - 1);

		int community_endNo = (community_page * community_rowsize);

		int community_startBlock = (((community_page - 1) / community_block) * community_block) + 1;

		int community_endBlock = (((community_page - 1) / community_block) * community_block) + community_block;


		
		community_count = dao.countCommunityBoardList();

		community_allPage = (int) Math.ceil(community_count / (double) community_rowsize);

		if (community_endBlock > community_allPage) {
			community_endBlock = community_allPage;
		}
		
		boolean is_cSearch = false;
		
		List<CommunityBoardDTO> list = dao.getCommunityBoardList(community_page,community_rowsize);
		

		request.setAttribute("community_page", community_page);
		request.setAttribute("community_rowsize", community_rowsize);
		request.setAttribute("community_block", community_block);
		request.setAttribute("community_count", community_count);
		request.setAttribute("community_allPage", community_allPage);
		request.setAttribute("community_startNo", community_startNo);
		request.setAttribute("community_endNo", community_endNo);
		request.setAttribute("community_startBlock", community_startBlock);
		request.setAttribute("community_endBlock", community_endBlock);
		request.setAttribute("list", list);
		request.setAttribute("is_cSearch", is_cSearch);

		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/public/boards/community_board_list.jsp");

		return forward;
	}

}