package com.car.action.sellcar;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.model.CarDTO;

public class ReqRegcarDetailAction implements Action{

   @Override
   public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
      String manufact_company = request.getParameter("manufact_company").trim();
      String type = request.getParameter("type").trim();
      int manufact_year = Integer.parseInt(request.getParameter("manufact_year").trim());
      String fuel = request.getParameter("fuel").trim();
      String transmission = request.getParameter("transmission").trim();
      String color = request.getParameter("color").trim();
      
      CarDTO dto = new CarDTO();
      
      dto.setCar_manufact_company(manufact_company);
      dto.setCar_type(type);
      dto.setCar_manufact_year(manufact_year);
      dto.setCar_fuel(fuel);
      dto.setCar_transmission(transmission);
      dto.setCar_color(color);
      
      String car_std_no = (manufact_company + "_"
                  + type + "_"
                  + manufact_year + "_"
                  + fuel.substring(0, 1) + "_"
                  + transmission + "_"
                  + color).toUpperCase();
               
      
      request.setAttribute("dto", dto);
      request.setAttribute("car_std_no", car_std_no);
      
      ActionForward forward = new ActionForward();
      
      forward.setPath("/WEB-INF/views/public/sellcar/req_regcar_detail.jsp");
      
      return forward;
   }

}