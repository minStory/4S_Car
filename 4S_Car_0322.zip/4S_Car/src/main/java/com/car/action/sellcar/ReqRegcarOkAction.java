package com.car.action.sellcar;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.model.ReqSellBoardDTO;
import com.car.model.TotalDAO;

public class ReqRegcarOkAction implements Action{

   @Override
   public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
      // 차량 상세정보 받아오기
      String user_no = request.getParameter("user_no").trim();
      String car_std_no = request.getParameter("car_std_no").trim();
      String car_model = request.getParameter("car_model").trim();
      String car_no = request.getParameter("car_no").trim();
      int car_distance = Integer.parseInt(request.getParameter("car_distance").trim());
      String car_detail = request.getParameter("car_detail").trim();
      
      // 파일 업로드 해야함!!
      String car_file = request.getParameter("file").trim();
      
      // 등록 요청 게시판 DTO에 정보 담기
      ReqSellBoardDTO dto = new ReqSellBoardDTO();
      dto.setReq_sell_board_user_no(user_no);
      dto.setReq_sell_board_car_std_no(car_std_no);
      dto.setReq_sell_board_car_model(car_model);
      dto.setReq_sell_board_car_no(car_no);
      dto.setReq_sell_board_car_distance(car_distance);
      dto.setReq_sell_board_car_detail(car_detail);
      dto.setReq_sell_board_file(car_file);
      
      // 날짜 정보 DTO에 정보 담기
      SimpleDateFormat ymd = new SimpleDateFormat("yyyyMMdd");   
      Calendar c1 = Calendar.getInstance();
      String date = ymd.format(c1.getTime());
      dto.setReq_sell_board_date(date);
      
      TotalDAO dao = TotalDAO.getInstance();
      
      int check = dao.insertRequestRegcar(dto);
      
      // ?????????????????
      PrintWriter w = response.getWriter();
      w.println("<script>");
      if(check > 0) {
         w.println("alert('딜러에게 정보 전송 완료')");
      }else {
         w.println("alert('딜러에게 정보 전송 실패')");
         w.println("history.back()");
      }
      w.println("</script>");
      
      // DB에 자동으로 count된 글번호 다시 DTO에 저장하기
      // -> 다음 화면에 바로 표시 목적
      dto.setReq_sell_board_no(dao.getReqSellBoardNo());
      
      request.setAttribute("dto", dto);
      
      ActionForward forward = new ActionForward();
      
      forward.setPath("/WEB-INF/views/public/sellcar/req_regcar_ok.jsp");
      
      return forward;
   }

}