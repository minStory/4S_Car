package com.car.model;

public class CarDTO {

	private String car_manufact_company;
	private int car_manufact_year;
	private int car_manufact_month;
	private String car_type;
	private String car_fuel;
	private String car_color;
	private String car_transmission;
	private String car_model;
	
	public String getCar_model() {
		return car_model;
	}
	public void setCar_model(String car_model) {
		this.car_model = car_model;
	}
	public String getCar_manufact_company() {
		return car_manufact_company;
	}
	public void setCar_manufact_company(String car_manufact_company) {
		this.car_manufact_company = car_manufact_company;
	}
	public int getCar_manufact_year() {
		return car_manufact_year;
	}
	public void setCar_manufact_year(int car_manufact_year) {
		this.car_manufact_year = car_manufact_year;
	}
	public int getCar_manufact_month() {
		return car_manufact_month;
	}
	public void setCar_manufact_month(int car_manufact_month) {
		this.car_manufact_month = car_manufact_month;
	}
	public String getCar_type() {
		return car_type;
	}
	public void setCar_type(String car_type) {
		this.car_type = car_type;
	}
	public String getCar_fuel() {
		return car_fuel;
	}
	public void setCar_fuel(String car_fuel) {
		this.car_fuel = car_fuel;
	}
	public String getCar_color() {
		return car_color;
	}
	public void setCar_color(String car_color) {
		this.car_color = car_color;
	}
	public String getCar_transmission() {
		return car_transmission;
	}
	public void setCar_transmission(String car_transmission) {
		this.car_transmission = car_transmission;
	}
	
	
	
}
