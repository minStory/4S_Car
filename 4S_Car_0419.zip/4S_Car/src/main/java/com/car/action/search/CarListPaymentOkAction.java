package com.car.action.search;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.model.SellBoardDTO;
import com.car.model.TotalDAO;
import com.car.model.UserDTO;

public class CarListPaymentOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		
		UserDTO cont = (UserDTO) session.getAttribute("dto");
		
		int board_no = Integer.parseInt(request.getParameter("no").trim());
		
		TotalDAO dao = TotalDAO.getInstance();
		
		SellBoardDTO dto = dao.getSellBoardContent(board_no);
		
		int check = dao.insertTransactionData(dto, cont.getUser_no());
		
		if(check > 0) {
			
			dao.updateSellBoardStatus(board_no);
			
			ActionForward forward = new ActionForward();
	        
		    forward.setPath("/WEB-INF/views/public/search/car_list_payment_ok.jsp");
		      
		    return forward;
		} else {
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('구매에 실패했습니다. 입력한 정보를 다시한번 확인해 주세요.')");
			out.println("history.back()");
			out.println("</script>");
			out.close();
		}
		
		return null;
	}

}
