// 모달 요소 가져오기
var paymentModal = document.getElementById("paymentModal");

// 모달 열기 버튼 가져오기
var popup_payment = document.getElementById("popup_payment");

// 모달을 닫는 데 사용되는 <span> 요소 가져오기
var closeSpan = document.getElementsByClassName("close")[0];

// 버튼을 클릭하면 모달 열기
popup_payment.onclick = function() {
    paymentModal.style.display = "block";
}

// <span> (x)를 클릭하면 모달 닫기
closeSpan.onclick = function() {
    paymentModal.style.display = "none";
}

// 모달 외부를 클릭하면 모달 닫기
window.onclick = function(event) {
    if (event.target == paymentModal) {
        paymentModal.style.display = "none";
    }
}