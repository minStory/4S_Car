function changePhone1(){
    let phone1 = document.getElementById("phone1").value
    if(phone1.length === 3){
        document.getElementById("phone2").focus();
    }  
}

function changePhone2(){
    let phone2 = document.getElementById("phone2").value
    if(phone2.length === 4){
        document.getElementById("phone3").focus();
    }
}
function changePhone3(){
    let phone3 = document.getElementById("phone3").value
    if(phone3.length === 4){
        document.getElementById("sendMessage").focus();
        document.getElementById("sendMessage").setAttribute("style","background-color:red;, color:white;")
        document.getElementById("sendMessage").disabled = false;
    }
}

/*// 문자인증 + 타이머

function  initButton(){
    document.getElementById("phone1").disabled = true;
    document.getElementById("phone2").disabled = true;
    document.getElementById("phone3").disabled = true;
    document.getElementById("sendMessage").disabled = true;
    document.getElementById("completion").disabled = true;
    document.getElementById("certificationNumber").innerHTML = "000000";
    document.getElementById("timeLimit").innerHTML = "3:00";
    document.getElementById("sendMessage").setAttribute("style","background-color:none;")
    document.getElementById("completion").setAttribute("style","background-color:none;")
    
}

let processID = -1;

const getToken = () => {
    //인증확인 버튼 활성화

    document.getElementById("completion").setAttribute("style","background-color:red")
    document.getElementById("completion").disabled = false;

    if(processID != -1) clearInterval(processID);
    const token = String(Math.floor(Math.random()* 1000000)).padStart(6,"0");
    document.getElementById("certificationNumber").innerText = token;


    let time = 180;

    processID = setInterval(function() {
        if(time < 0 || document.getElementById("sendMessage").disabled){
            clearInterval(processID);
            initButton();
         return;
        }
        let mm =String(Math.floor(time / 60)).padStart(1,"0");
        let ss =String(time % 60).padStart(2,"0");
        document.getElementById("timeLimit").innerText = (mm + ":" + ss);
        time --;
        
        
    }, 1000);
};

function checkCompletion(){
    alert("문자 인증이 완료되었습니다.")
    initButton();
    document.getElementById("completion").innerHTML = "인증완료";
    document.getElementById("signUpButton").disabled = false;
    document.getElementById("signUpButton").setAttribute("style","background-color:#e32b30;")


    let name = document.getElementById("name").value
    let id = document.getElementById("id").value
    let email = document.getElementById("email").value
    let password = document.getElementById("password").value
    let passwordCheck = document.getElementById("passwordcheck").value
    let phone1 = document.getElementById("phone1").value
    let phone2 = document.getElementById("phone2").value
    let phone3 = document.getElementById("phone3").value
    
    var send = document.getElementById("signUpButton");
	send.addEventListener("click", function () {
		  var form = document.getElementById("form");
		  var id = document.getElementById("name");
		  var pw = document.getElementById("password");
		  var email = document.getElementById("email");
		  var pwcheck = document.getElementById("passwordcheck");
		  
	
		  if (pw.value.trim() == "" || id.value.trim() == "" ) {
		    alert("회원가입 폼 페이지 작성란을 확인해 주세요");
		    return false;
		  }
	
		  form.action = "./signup_ok";
		  form.method = "post";
		  form.submit();
	});
    
}*/




//id =>중복확인 버튼을 눌렀을 때 중복이면 경고메세지를 띄운다.


//password => 공백이거나 8자리 이상이 아니면 경고메세지를 띄운다.
// if(password !== null && password.value.length >= 8){
//     document.getElementById("password_Error").innerHTML = "사용가능한 비밀번호입니다."
// }
// else if(password == null){
//     document.getElementById("password_Error").innerHTML = "비밀번호를 입력해 주세요"
// }else if(password.value.length < 8){
//     document.getElementById("password_Error").innerHTML = "비밀번호는 8자리 이상이어야 합니다."
// }else{
//     document.getElementById("password_Error").innerHTML = "비밀번호를 다시 확인해주세요."
// }

//password => 공백이거나 위의 password와 비교했을때 같지 않으면 경고메세지를 띄운다.


//email => @기호를 포함하지 않거나 뒤에 주소가 이상하면 경고메세지를 띄운다.


//name => 이름 입력란에 공백이면 경고메세지를 띄운다.


