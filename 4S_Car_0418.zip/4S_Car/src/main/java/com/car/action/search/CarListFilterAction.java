package com.car.action.search;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.action.StaticArea;
import com.car.model.SellBoardDTO;
import com.car.model.TotalDAO;

public class CarListFilterAction implements Action{

   @Override
   public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {
      
      List<String> typeList = null;
      List<String> companyList = null;
      List<String> colorList = null;
      List<String> fuelList = null;
      List<String> transmissionList = null;
      
      if(request.getParameterValues("type") != null) {
         typeList = Arrays.asList(request.getParameterValues("type"));
      }
      if(request.getParameterValues("company") != null) {
         companyList = Arrays.asList(request.getParameterValues("company"));
      }
      if(request.getParameterValues("color") != null) {
         colorList = Arrays.asList(request.getParameterValues("color"));
      }
      if(request.getParameterValues("fuel") != null) {
         fuelList = Arrays.asList(request.getParameterValues("fuel"));
      }
      if(request.getParameterValues("transmission") != null) {
         transmissionList = Arrays.asList(request.getParameterValues("transmission"));
      }
      
      int min_year = 0;
      int max_year = Integer.MAX_VALUE;
      int min_distance = 0;
      int max_distance = Integer.MAX_VALUE;
      int min_price = 0;
      int max_price = Integer.MAX_VALUE;
      
      if(request.getParameter("min_year").trim() != "") {
         min_year = Integer.parseInt(request.getParameter("min_year").trim());
      }
      if(request.getParameter("max_year").trim() != "") {
         max_year = Integer.parseInt(request.getParameter("max_year").trim());
      }
      if(request.getParameter("min_distance").trim() != "") {
         min_distance = Integer.parseInt(request.getParameter("min_distance").trim());
      }
      if(request.getParameter("max_distance").trim() != "") {
         max_distance = Integer.parseInt(request.getParameter("max_distance").trim());
      }
      if(request.getParameter("min_price").trim() != "") {
         min_price = Integer.parseInt(request.getParameter("min_price").trim()) * 10000;
      }
      if(request.getParameter("max_price").trim() != "") {
         max_price = Integer.parseInt(request.getParameter("max_price").trim()) * 10000;
      }
      
      if(min_year > max_year) {
         min_year = 0;
         max_year = Integer.MAX_VALUE;
      }
      if(min_distance > max_distance) {
         min_distance = 0;
         max_distance = Integer.MAX_VALUE;
      }
      if(min_price > max_price) {
         min_price = 0;
         max_price = Integer.MAX_VALUE;
      }
      
      
       TotalDAO dao = TotalDAO.getInstance();
       
       List<SellBoardDTO> list = dao.getFilterSearch(typeList, companyList, colorList, fuelList, transmissionList,
                         min_year, max_year, min_distance, max_distance, min_price, max_price);
       
           
       List<Integer> companyCountList = dao.getCountCompany(StaticArea.getCompanyList());
         
       int allCount = dao.getCarListAllCount();
       int count = list.size();
      
      request.setAttribute("allCount", allCount);
       request.setAttribute("count", count);
       request.setAttribute("list", list);
       request.setAttribute("typeList", StaticArea.getTypeList());
       request.setAttribute("companyList", StaticArea.getCompanyList());
       request.setAttribute("companyCountList", companyCountList);
       request.setAttribute("colorList", StaticArea.getColorList());
       request.setAttribute("fuelList", StaticArea.getFuelList());
       request.setAttribute("transmissionList", StaticArea.getTransmissionList());
       request.setAttribute("filterList", StaticArea.getFilterList());
       request.setAttribute("sequenceList", StaticArea.getSequenceList());
      
      ActionForward forward = new ActionForward();
         
       forward.setPath("/WEB-INF/views/public/search/car_list.jsp");
      
      return forward;
   }

}