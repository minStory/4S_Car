package com.car.admin.boards;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.model.ReqSellBoardDTO;
import com.car.model.TotalDAO;

public class ReqRegcarListAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		  TotalDAO dao = TotalDAO.getInstance();
	      
	      List<ReqSellBoardDTO> list = dao.getReqSellBoardList();
	      
	      request.setAttribute("list", list);
	      
	      ActionForward forward = new ActionForward();
	      
	      forward.setPath("/WEB-INF/views/admin/boards/req_regcar_list.jsp");
	      
	      return forward;

	}

}
