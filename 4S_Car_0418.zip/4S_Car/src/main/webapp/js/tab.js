function openTab(evt, tabName) {
    var i, tabcontent, tablinks;

    // 모든 탭 내용을 숨김
    tabcontent = document.getElementsByClassName("tab-item");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    // 모든 탭 버튼의 활성화 상태 제거
    tablinks = document.getElementsByClassName("tab-item");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].classList.remove("active");
    }

    // 해당 탭 내용을 표시하고, 탭 버튼을 활성화 상태로 변경
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.parentElement.classList.add("active");
}

// 페이지 로드 시 초기 설정
document.addEventListener("DOMContentLoaded", function(event) {
    var eventBar = document.querySelector('.event-bar');
    var noticeBar = document.querySelector('.notice-bar');
    var qnaBar = document.querySelector('.qna-bar');
    var tabBtn1 = document.querySelector('.tab-item-1');
    var tabBtn2 = document.querySelector('.tab-item-2');
    var tabBtn3 = document.querySelector('.tab-item-3');
    var bluebar = document.querySelector('.blue-bar');
    
   
    
    
    // 초기에 공지사항 버튼이 선택되어 있으므로 파란선이 있고, 이벤트 버튼 아래에는 회색선이 있도록 설정
    noticeBar.style.display = "block";
    noticeBar.style.backgroundColor = "rgb(92, 159, 236)"; // 파란색
    tabBtn1.style.color = "rgb(92, 159, 236)";
    eventBar.style.backgroundColor = "#cccccc";
  
   

    // 이벤트 리스너 등록
    tabBtn1.addEventListener('click', function() {
        // 공지사항 버튼을 클릭하면 파란선 표시, 이벤트, 문의함 버튼 아래에 회색선 표시
       	tabBtn1.style.display = "block";
       	tabBtn1.style.color = "#5c9fec";
        noticeBar.style.backgroundColor = "#5c9fec"; // 파란색
        tabBtn2.style.display = "block";
        tabBtn2.style.color = "#16171d";
        eventBar.style.backgroundColor = "#cccccc"; // 회색
        tabBtn3.style.display = "block";
        tabBtn3.style.color = "#16171d";
        qnaBar.style.backgroundColor = "#cccccc";
    });

    tabBtn2.addEventListener('click', function() {
        // 이벤트 버튼을 클릭하면 파란선 표시, 공지사항, 문의함 버튼 아래에 회색선 표시
        tabBtn1.style.display = "block";
        tabBtn1.style.color = "#16171d"; // 회색
        noticeBar.style.backgroundColor = "#cccccc"; // 
        tabBtn2.style.display = "block";
        tabBtn2.style.color = "#5c9fec";
        eventBar.style.backgroundColor = "rgb(92, 159, 236)"; // 파란색
        tabBtn3.style.display = "block";
        tabBtn3.style.color = "#16171d";
        qnaBar.style.backgroundColor = "#cccccc";
    });
    
    tabBtn3.addEventListener('click', function() {
        // 문의함 버튼을 클릭하면 파란선 표시, 공지사항, 이벤트 버튼 아래에 회색선 표시
        tabBtn1.style.display = "block";
        tabBtn1.style.color = "#16171d";
        noticeBar.style.backgroundColor = "#cccccc"; // 회색
        tabBtn2.style.display = "block";
        tabBtn2.style.color = "#16171d";
        eventBar.style.backgroundColor = "#cccccc"; // 파란색
        tabBtn3.style.display = "block";
        tabBtn3.style.color = "#5c9fec";
        qnaBar.style.backgroundColor = "rgb(92, 159, 236)";
    });
    
    
   
    
    // notice-bar 클릭 시 이벤트 전파 중지 및 비활성화
    noticeBar.addEventListener('click', function(event) {
        event.stopPropagation(); // 이벤트 전파 중지
        eventBar.style.pointerEvents = "none"; // 이벤트 바 비활성화
    });

    // event-bar 클릭 시 이벤트 전파 중지 및 비활성화
    eventBar.addEventListener('click', function(event) {
        event.stopPropagation(); // 이벤트 전파 중지
        noticeBar.style.pointerEvents = "none"; // 공지사항 바 비활성화
    });
    
    qnaBar.addEventListner('click', function(event) {
    	event.stopPropagation();
    	qnaBar.style.pointerEvents = "none";
    });
});