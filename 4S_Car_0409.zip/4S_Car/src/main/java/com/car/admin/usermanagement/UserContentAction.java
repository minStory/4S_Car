package com.car.admin.usermanagement;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.model.TotalDAO;
import com.car.model.UserDTO;

public class UserContentAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String user_no = request.getParameter("no").trim();
		
		TotalDAO dao = TotalDAO.getInstance();
		
		UserDTO dto = dao.getUserContent(user_no);
		
		request.setAttribute("dto", dto);
		
		ActionForward forward = new ActionForward();
		
		forward.setPath("/WEB-INF/views/admin/usermanagement/user_content.jsp");
		
		return forward;
	}

}
