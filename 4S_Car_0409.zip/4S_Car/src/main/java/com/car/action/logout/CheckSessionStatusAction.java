package com.car.action.logout;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.model.TotalDAO;

public class CheckSessionStatusAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession session = request.getSession(false);
		
        if (session == null || session.getAttribute("name") == null) {
        	String user_no = (String) session.getAttribute("no");
            TotalDAO dao = TotalDAO.getInstance();
            
            dao.remainLogout(user_no);
            // 세션이 없거나 사용자가 인증되지 않은 경우 "expired"를 반환합니다.
        	session.invalidate();
            response.getWriter().print("expired");
        } else {
            // 세션이 유효한 경우
        	response.getWriter().write("valid");
        }
		
		return null;
	}

}
