
$(function(){

    $("#scroll_top").click(function(){
        $("html").animate({ scrollTop: 0 });
    })
        
});

$(function(){

	if($("div").hasClass("login_page")){
		$("div.inner").remove();
	}
	if($("main").hasClass("main_sign_up")){
		$("div.inner").remove();
	}
	
	var sc;
	
    $(window).scroll(function(){ 

            sc = $("html").scrollTop(); 
      	
            if(sc > 0){
            	$(".scroll_top").fadeIn(300);
            }else{
            	$(".scroll_top").fadeOut(300);
            }
       })
	
});
   
$(document).ready(function() {

    $.ajax({
        type: "POST",
        url: "check_login_status",
        success: function(response) {
            if (response.loggedIn == 1) {
            
                // 유저 로그인 상태일 경우
                $('.login_main').hide(); // 로그인 버튼 숨기기
                $('#admin_btn').hide(); // 관리자 로그인 버튼 숨기기
                $('.logout').show();
                $('#user_name').html('<a href="mypage">' + response.username + '</a> 님');
                $('#user_name').show();
                
                // 사용자 번호도 함께 받아오기
                var userno = response.userno;
            } else if(response.loggedIn == 0){
            
            	// 관리자 로그인 상태일 경우
                $('.login_main').hide();    // 로그인 버튼 숨기기
                $('#admin_btn').hide();     // 관리자 로그인 버튼 숨기기
                $('#admin_page_btn').show(); // 관리자 페이지 버튼 보이기
                $('.logout').show();
                $('#user_name').html('<a href="admin_main">' + response.adminname + '</a> 님');
                $('#user_name').show();
                
                // 사용자 번호도 함께 받아오기
                var adminno = response.adminno;
                
                $('#my_page').removeAttr("onclick");
            	$('#my_page').click(function() {
            		alert("관리자로 로그인했습니다!!");
            	})
            	$('#car_sell_btn').removeAttr("onclick");
            	$('#car_sell_btn').click(function() {
            		alert("관리자로 로그인했습니다!!");
	            })
	            $('.lnb-item #login_first').removeAttr("href");
	            $('.lnb-item #login_first').mouseover(function() {
            		$('.lnb-item #login_first').css("cursor", "pointer");
            	})
            	$('.lnb-item #login_first').click(function() {
            		alert("관리자로 로그인했습니다!!");
            	})
            } else {
            	
            	$('#my_page').removeAttr("onclick");
            	$('#my_page').click(function() {
            		alert("로그인 후 이용하실 수 있습니다.");
            		location.href='user_login';
            	})
            	$('#car_sell_btn').removeAttr("onclick");
            	$('#car_sell_btn').click(function() {
            		alert("로그인 후 이용하실 수 있습니다.");
            		location.href='user_login';
	            })
	            $('.lnb-item #login_first').removeAttr("href");
	            $('.lnb-item #login_first').mouseover(function() {
            		$('.lnb-item #login_first').css("cursor", "pointer");
            	})
            	$('.lnb-item #login_first').click(function() {
            		alert("로그인 후 이용하실 수 있습니다.");
            		location.href='user_login';
            	})
            	
            	
            	return false;
            }
        }
    });
    
    $.ajax({
        type: "GET",
        url: "print_notice", // 공지사항을 가져오는 서블릿의 URL
        dataType: "json",
        success: function(response) {
            if(response.length === 0) {
            	// 공지사항이 없는 경우
            	$("#notice_box").html("<div class='trave1'>등록된 공지사항이 없습니다.</div>");
            } else {
	            // 공지사항 리스트를 받아서 필요한 작업을 수행
	            printNotices(response);
            }
        },
        error: function(xhr, status, error) {
            // 오류 발생 시 처리
            console.error("오류:", error);
        }
    });
    
    function printNotices(notices) {
        var noticesHtml = "";
        $.each(notices, function(index, notice) {
            noticesHtml += "<div class='trave1'>";
            noticesHtml += "<a href='notice_list'>" + notice.title + "</a>&nbsp;&nbsp;&nbsp;";
            noticesHtml += "<span>" + notice.date.substring(0, 10) + "</span>";
            noticesHtml += "</div>";
        });
        $(".travel #notice_box").html(noticesHtml);
        $('a').hover(function() {
            $(this).css("text-decoration", "underline");
        },function() {
            $(this).css('text-decoration', 'none');
        })
      }
})

var a = setInterval("test()",3000); 


function test(){

    $(".main_visual ul:first").stop().animate({ marginLeft:"-100%"},function(){ //동작, 이미지 슬라이드 과정을 볼 수 있습니다.

        $(".main_visual ul:first li:first").appendTo(".main_visual ul:first"); //조작
        $(".main_visual ul:first").css({ marginLeft: 0 }); // 조작

    });

};


// 로그아웃 버튼 클릭 시
$(document).on('click', '#logout_btn', function(e) {
    e.preventDefault(); // 기본 동작 중단

    $.ajax({
        type: "GET",
        url: "logout", // 로그아웃 요청을 보낼 URL
        success: function(response) {
        	alert('로그아웃 했습니다.');
            window.location.reload(true);
        }
	});
});