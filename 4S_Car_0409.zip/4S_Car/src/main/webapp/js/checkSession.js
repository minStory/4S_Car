function checkSessionStatus() {
    var sessionUsername = '<%= session.getAttribute("name") %>';
    
    // 세션이 존재하는 경우에만 AJAX 요청을 보냅니다.
    if (sessionUsername !== null && sessionUsername !== '') {
        $.ajax({
            url: 'check_session_status', // Action 클래스로 요청을 보냅니다.
            success: function(response) {
                if (response === "expired") {
                    alert("세션이 만료되어 로그아웃 합니다.");
                    window.location.href = 'main.jsp';
                }
            }
        });
    }
}

$(document).ready(function() {
    setInterval(checkSessionStatus, 1799995); // 1분(60초)마다 함수 호출
});