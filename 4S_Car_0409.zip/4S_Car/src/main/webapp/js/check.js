

var Btn1 = document.querySelector(".check-label");


Btn1.addEventListener('click', function() {

  
  Btn1.style.borderColor = "#5c9fec";

});


document.addEventListener("DOMContentLoaded", function() {
  // 각 carsort 클래스 요소를 가져옴
  var carSorts = document.querySelectorAll('.carsort');

  // 각 carsort 요소에 대해 이벤트 리스너 설정
  carSorts.forEach(function(carSort) {
    // 화살표 아이콘을 가져옴
    var arrowIcon = carSort.querySelector('.arrow');
    // 클릭 이벤트 리스너 설정
    arrowIcon.addEventListener('click', function() {
      // 해당 carsort 요소에서 다음 형제 요소를 찾아서 상세 내역을 토글함
      var carItem = carSort.querySelector('.caritem');
      if (carItem.style.display === 'none' || carItem.style.display === '') {
        carItem.style.display = 'block';
      } else {
        carItem.style.display = 'none';
      }
    });
  });
});


document.addEventListener("DOMContentLoaded", function() {
  const scrollbarWrap = document.querySelector(".scrollerbarWrap");
  const scrollbarView = document.querySelector(".scrollerbarView");
  const modelList = document.querySelector(".modelList");

  const scrollerbarHeight = scrollbarWrap.clientHeight / modelList.scrollHeight * scrollbarWrap.clientHeight;
  scrollbarView.style.height = scrollerbarHeight + "px";

  modelList.addEventListener("scroll", function() {
    const scrollPercentage = modelList.scrollTop / (modelList.scrollHeight - modelList.clientHeight);
    const scrollbarTop = scrollPercentage * (scrollbarWrap.clientHeight - scrollerbarHeight);
    scrollbarView.style.top = scrollbarTop + "px";

  });
});




function toggleBorderColor(button) {
  button.classList.toggle('clicked'); // 'clicked' 클래스를 토글합니다.
}