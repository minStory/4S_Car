package com.car.action.login;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.model.TotalDAO;
import com.car.model.UserDTO;

public class UserLoginOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String user_id = request.getParameter("user_id").trim();
		String user_pwd = request.getParameter("user_pwd").trim();
		
		UserDTO dto = new UserDTO();
		
		dto.setUser_id(user_id);
		dto.setUser_pwd(user_pwd);
		
		TotalDAO dao = TotalDAO.getInstance();
		
		int check = dao.checkUserLogin(dto);
		
		PrintWriter out = response.getWriter();
		
		if(check == 1) {
			
			HttpSession session = request.getSession();
			UserDTO cont = dao.getUserContent(dto);
			session.setAttribute("name", cont.getUser_name());
			session.setAttribute("no", cont.getUser_no());
			session.setAttribute("dto", cont);
			out.println("<script>");
			out.println("alert('로그인했습니다.')");
			out.println("</script>");
			response.sendRedirect(request.getContextPath() + "/main.jsp");
			
		} else if(check == -1) {
			out.println("<script>");
			out.println("alert('비밀번호가 일치하지 않습니다!')");
			out.println("history.back()");
			out.println("</script>");
		} else  {
			out.println("<script>");
			out.println("alert('일치하는 아이디를 찾을수 없습니다.')");
			out.println("history.back()");
			out.println("</script>");
		} 
		out.close();
		return null;
	}
	
}
