package com.car.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class TotalDAO {
	
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sql = "";

	// TotalDAO 객체를 싱글톤 방식으로 만든다.

	// 1. TotalDAO 객체를 정적(static) 멤버로 선언 해 준다.
	private static TotalDAO instance = null;

	// 2. 기본 생성자를 private 로 선언한다.
	private TotalDAO() {}

	// 3. 기본 생성자 대신 instance 를 return 해 주는 getInstance() 매서드 선언.
	public static TotalDAO getInstance() {

		if (instance == null) {
			instance = new TotalDAO();
		}

		return instance;
	} // getInstance() end.

	
	// JDBC 방식이 아닌 DBCP 방식으로 DB와 연동 작업 진행.
	public void openConn() {

		try {
			
			// 1. JNDI 서버 객체 생성.
			// 자바의 네이밍 서비스(JNDI)에서 이름과 실제 객체를 연결 해 주는 개념이 Context 객체이며
			// , InitialContext 객체는 네이밍 서비스를 이용하기 위한 시작점이 된다.
			Context initCtx = new InitialContext();
			
			// 2. Context 객체를 얻어와야 함.
			// "java:comp/env" 라는 이름의 인수로 Context 객체를 얻어옴.
			// "java:comp/env" 는 현재 웹 애플리케이션에서 네이밍 서비스를 이용시 루트 디렉토리라고 생각하면 됨.
			// 즉, 현재 웹 애플리케이션이 사용 할 수 있는 모든 자원은 "java:comp/env" 아래에 위치를 하게 됨.
			Context ctx = (Context)initCtx.lookup("java:comp/env");
			
			// 3. lookup() 매서드를 이용하여 매칭되는 커넥션을 찾아옴.
			// "java:comp/env" 아래에 위치한 "jdbc/mysql" 자원을 얻어옴
			// 이 자원이 바로 데이터 소스(커넥션 풀)임.
			// 여기서 "jdbc/mysql" 은 context.xml 파일에 추가했던
			// <Resource> 태그 안에 있던 name 속성의 값임.
			DataSource ds = (DataSource)ctx.lookup("jdbc/mysql");
			
			// 4. DataSource 객체를 이용하여 커넥션을 하나 가져오면 됨.
			con = ds.getConnection();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	} // openConn() end.

	
	// DB에 연결된 자원을 종료하는 매서드.
	public void closeConn(ResultSet rs, PreparedStatement pstmt, Connection con) {

		try {

			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();
			if (con != null) con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	} // closeConn() end.

	public void closeConn(PreparedStatement pstmt, Connection con) {

		try {

			if (pstmt != null) pstmt.close();
			if (con != null) con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	} // closeConn() end.
	
	
	
	// 회원가입 페이지에서 입력받은 회원의 정보를 user Table에 insert 하는 매서드. 
	public int insertUser(UserDTO dto) {
		
		int result = 0, cnt = 0;

		try {

			openConn();
			
			sql = "select count(user_no) from user where user_no like ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, dto.getUser_no()+"%");
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				cnt = rs.getInt(1)+1;
			}
			
			sql = "insert into user values(?,?,?,?,?,?, default, default, default)";
			
			pstmt = con.prepareStatement(sql);
			
			if(cnt < 10) {
				pstmt.setString(1, dto.getUser_no()+"00"+cnt);
			} else if(cnt < 100) {
				pstmt.setString(1, dto.getUser_no()+"0"+cnt);
			} else {
				pstmt.setString(1, dto.getUser_no()+cnt);
			}
			pstmt.setString(2, dto.getUser_id());
			pstmt.setString(3, dto.getUser_pwd());
			pstmt.setString(4, dto.getUser_name());
			pstmt.setString(5, dto.getUser_phone());
			pstmt.setString(6, dto.getUser_email());
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		
		return result;
	} // insertUser(dto) end.
	
	
	
	// 사용자가 입력한 id와 pwd 가 유효한 값인지 check 하는 매서드.
	public int checkUserLogin(UserDTO dto) {
		
		int result = 0;
		
		try {

			openConn();
			
			sql = "select * from user where user_id = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, dto.getUser_id());
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {		// 입력받은 아이디와 일치한 아이디가 DB에 존재할 경우
				if(dto.getUser_pwd().equals(rs.getString("user_pwd"))) {	// 아이디가 존재하고, 입력받은 pwd가 일치 할 경우
					result = 1;
				}else {		// 일치하는 아이디가 DB에 존재하지만 입력한 비밀번호가 틀린경우
					result = -1;
				}
			} else {	// 입력받은 아이디가 DB에 존재하지 않을 경우.
				result = 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		
		return result;
	}	// checkUserLogin(dto) end.
	
	
	
	// 로그인 페이지에서 유효성 검사를 통과 후 관련 회원 정보를 모두 불러오는 매서드.
	public UserDTO getUserContent(UserDTO dto) {
		
		UserDTO cont = new UserDTO();
		
		try {

			openConn();
			
			sql = "select * from user where user_id = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, dto.getUser_id());
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				cont.setUser_no(rs.getString("user_no"));
				cont.setUser_id(rs.getString("user_id"));
				cont.setUser_pwd(rs.getString("user_pwd"));
				cont.setUser_name(rs.getString("user_name"));
				cont.setUser_phone(rs.getString("user_phone"));
				cont.setUser_email(rs.getString("user_email"));
				cont.setUser_mileage(rs.getInt("user_mileage"));
				cont.setUser_grade(rs.getString("user_grade"));
				cont.setUser_regdate(rs.getString("user_regdate"));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		
		return cont;
	}	// userContent(dto) end.
	
	
	
	// User_no 으로 회원정보를 조회하는 매서드(오버로딩).
	public UserDTO getUserContent(String user_no) {
		
		UserDTO cont = new UserDTO();
		
		try {

			openConn();
			
			sql = "select * from user where user_no = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, user_no);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				cont.setUser_no(rs.getString("user_no"));
				cont.setUser_id(rs.getString("user_id"));
				cont.setUser_pwd(rs.getString("user_pwd"));
				cont.setUser_name(rs.getString("user_name"));
				cont.setUser_phone(rs.getString("user_phone"));
				cont.setUser_email(rs.getString("user_email"));
				cont.setUser_mileage(rs.getInt("user_mileage"));
				cont.setUser_grade(rs.getString("user_grade"));
				cont.setUser_regdate(rs.getString("user_regdate"));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		
		return cont;
	}	// userContent(user_no) end.
	
	
	
	// 회원가입 폼에서 id 중복체크 하는 매서드.
	public int checkUserId(String user_id) {
		
		int result = 0;
		
		try {

			openConn();
			
			sql = "select * from user where user_id = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, user_id);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				result = -1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		
		return result;
	}	// checkUserId(userId) end.
	
	
	
	//	관리자 로그인 유효성 검사 매서드.
	public int checkAdminLogin(AdminDTO dto) {
		
		int result = 0;
		
		try {

			openConn();
			
			sql = "select * from admin where admin_id = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, dto.getAdmin_id());
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {		// 입력받은 아이디와 일치한 아이디가 DB에 존재할 경우
				if(dto.getAdmin_pwd().equals(rs.getString("admin_pwd"))) {	// 아이디가 존재하고, 입력받은 pwd가 일치 할 경우
					result = 1;
				}else {		// 일치하는 아이디가 DB에 존재하지만 입력한 비밀번호가 틀린경우
					result = -1;
				}
			} else {	// 입력받은 아이디가 DB에 존재하지 않을 경우.
				result = 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		
		return result;
	}	// checkAdminLogin(dto) end.
	
	
	// 관리자 로그인 페이지에서 유효성 검사를 통과 후 관련 관리자 정보를 모두 불러오는 매서드.
	public AdminDTO adminContent(AdminDTO dto) {
		
		AdminDTO cont = new AdminDTO();
		
		try {

			openConn();
			
			sql = "select * from admin where admin_id = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, dto.getAdmin_id());
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				cont.setAdmin_no(rs.getString("admin_no"));
				cont.setAdmin_id(rs.getString("admin_id"));
				cont.setAdmin_pwd(rs.getString("admin_pwd"));
				cont.setAdmin_name(rs.getString("admin_name"));
				cont.setAdmin_job(rs.getString("admin_job"));
				cont.setAdmin_phone(rs.getString("admin_phone"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		
		return cont;
	}	// adminContent(dto) end.
	
	
	
	
	// 판매 요청 게시판에 글 업로드하는 메서드
   public int insertReqRegcar(ReqSellBoardDTO dto) {
         
         int result = 0, count = 0;
         
         try {
            openConn();
            
            // 글번호 카운트
            sql = "select max(req_sell_board_no) from req_sell_board";
            
            pstmt = con.prepareStatement(sql);
            
            rs = pstmt.executeQuery();
            
            if(rs.next()) {
               count = rs.getInt(1);
            }
            
            // DB에 데이터 저장
            sql = "insert into req_sell_board values(?, ?, ?, ?, ?, ?, ?, default, null, ?, default)";
            
            pstmt = con.prepareStatement(sql);
            
            pstmt.setInt(1, count + 1);
            pstmt.setString(2, dto.getReq_sell_board_user_no());
            pstmt.setString(3, dto.getReq_sell_board_car_std_no());
            pstmt.setString(4, dto.getReq_sell_board_car_no());
            pstmt.setInt(5, dto.getReq_sell_board_car_distance());
            pstmt.setInt(6, dto.getReq_sell_board_car_price());
            pstmt.setString(7, dto.getReq_sell_board_car_detail());
            pstmt.setString(8, dto.getReq_sell_board_car_file());
            
            result = pstmt.executeUpdate();
            
         }catch(Exception e) {
            e.printStackTrace();
         }finally {
            closeConn(rs, pstmt, con);
         }
         
         return result;
      }
	      
      // DB에 정보 저장 후 등록 요청 게시판 글번호 가져오는 메서드
      public int getReqSellBoardNo() {
         
         int result = 0;
         
         try {
            openConn();
            
            sql = "select max(req_sell_board_no) from req_sell_board";
            
            pstmt = con.prepareStatement(sql);
            
            rs = pstmt.executeQuery();
            
            if(rs.next()) {
               result = rs.getInt(1);
            }
            
         }catch(Exception e) {
            e.printStackTrace();
         }finally {
            closeConn(rs, pstmt, con);
         }
         
         return result;
      }
	      
      // DB에 정보 저장 후 등록 요청 게시판 요청일자 가져오는 메서드
      public String getReqSellBoardDate() {
         
         String result = null ;
         
         try {
            
            openConn();
            
            sql = "select max(req_sell_board_date) from req_sell_board";
            
            pstmt = con.prepareStatement(sql);
            
            rs = pstmt.executeQuery();
            
            if(rs.next()) {
               result = rs.getString(1);
            }
         }catch(Exception e) {
            e.printStackTrace();
         }finally {
            closeConn(rs, pstmt, con);
         }
         
         return result;
      }
	
      
      
      public List<ReqSellBoardDTO> getReqSellBoardList(){
          
			List<ReqSellBoardDTO> list = new ArrayList<>();
			
			try {
				
				openConn();
				
				sql = "select * from req_sell_board where req_sell_board_status = false order by req_sell_board_no";
				
				pstmt = con.prepareStatement(sql);
				
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					
					ReqSellBoardDTO dto = new ReqSellBoardDTO();
				
					dto.setReq_sell_board_no(rs.getInt("req_sell_board_no"));
					dto.setReq_sell_board_user_no(rs.getString("req_sell_board_user_no"));
					dto.setReq_sell_board_car_std_no(rs.getString("req_sell_board_car_std_no"));
					dto.setReq_sell_board_car_no(rs.getString("req_sell_board_car_no"));
					dto.setReq_sell_board_car_distance(rs.getInt("req_sell_board_car_distance"));
					dto.setReq_sell_board_car_price(rs.getInt("req_sell_board_car_price"));
					dto.setReq_sell_board_car_detail(rs.getString("req_sell_board_car_detail"));
					dto.setReq_sell_board_date(rs.getString("req_sell_board_date"));
					dto.setReq_sell_board_update(rs.getString("req_sell_board_update"));
					dto.setReq_sell_board_car_file(rs.getString("req_sell_board_car_file"));
					dto.setReq_sell_board_status(rs.getBoolean("req_sell_board_status"));
					
					list.add(dto);
				}
			
			} catch(Exception e) {
				e.printStackTrace();
			} finally {
				closeConn(rs, pstmt, con);
			}
			
			return list;
		}                                 
	
      
      // 회원 수정 폼페이지에서 수정 할 정보를 user 테이블에 update하는 매서드.
      public int updateUserInfo(UserDTO dto) {
    	  
    	  int result = 0;
    	  
    	  try {

        	openConn();
        	  
        	sql = "update user set user_pwd = ?, user_phone = ?, user_email = ? where user_no = ?";
        	  
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, dto.getUser_pwd());
			pstmt.setString(2, dto.getUser_phone());
			pstmt.setString(3, dto.getUser_email());
			pstmt.setString(4, dto.getUser_no());
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(pstmt, con);
		}
    	  
    	  return result;
      } 	// updateUserInfo(dto) end.
      
      
      //	관리자에게 유저들의 리스트를 넘겨주는 매서드.
      public List<UserDTO> getUserList(){
          
          List<UserDTO> list = new ArrayList<>();
          
          try {
	          openConn();
	          
	          sql = "select * from user order by user_no";
	          
	          pstmt = con.prepareStatement(sql);
	          
	          rs = pstmt.executeQuery();
	          
	          while(rs.next()) {
	             
	             UserDTO dto = new UserDTO();
	          
	             dto.setUser_no(rs.getString("user_no"));
	             dto.setUser_id(rs.getString("user_id"));
	             dto.setUser_name(rs.getString("user_name"));
	             dto.setUser_phone(rs.getString("user_phone"));
	             dto.setUser_email(rs.getString("user_email"));
	             dto.setUser_mileage(rs.getInt("user_mileage"));
	             dto.setUser_grade(rs.getString("user_grade"));
	             dto.setUser_regdate(rs.getString("user_regdate"));
	             
	             list.add(dto);
	          }
          
          } catch(Exception e) {
             e.printStackTrace();
          } finally {
             closeConn(rs, pstmt, con);
          }
          		return list;
          }
      
      
      // 	관리자에게 QnA 리스트를 넘겨주는 매서드.
      public List<QnaBoardDTO> getQnaBoardList(){
    	  
    	  List<QnaBoardDTO> list = new ArrayList<QnaBoardDTO>();
    	  
    	  try {

        	  openConn();
        	  
        	  sql = "select * from qna_board order by qna_board_no";
        	  
			  pstmt = con.prepareStatement(sql);
			  
			  rs = pstmt.executeQuery();
			  
			  while(rs.next()) {
				  
				  QnaBoardDTO dto = new QnaBoardDTO();
				  
				  dto.setQna_board_no(rs.getInt("qna_board_no"));
				  dto.setQna_board_type(rs.getString("qna_board_type"));
				  dto.setQna_board_writer_id(rs.getString("qna_board_writer_id"));
				  dto.setQna_board_title(rs.getString("qna_board_title"));
				  dto.setQna_board_cont(rs.getString("qna_board_cont"));
				  dto.setQna_board_date(rs.getString("qna_board_date"));
				  dto.setQna_board_update(rs.getString("qna_board_update"));
				  dto.setQna_board_file(rs.getString("qna_board_file"));
				  
				  list.add(dto);
			  }
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
    	  return list;
      }		// getQnaBoardList() end.
      
      
      // 관리자 페이지에서 DB에 등록된 회사 정보를 가져오는 매서드.
      public CompanyDTO getCompanyInfo() {
          
          CompanyDTO dto = null;
          
          try {
             openConn();
             
             sql = "select * from company";
             
             pstmt = con.prepareStatement(sql);
             
             rs = pstmt.executeQuery();
             
             if(rs.next()) {
                
                dto = new CompanyDTO();
                
                dto.setCompany_business_no(rs.getString("company_business_no"));
                dto.setCompany_name(rs.getString("company_name"));
                dto.setCompany_ceo_name(rs.getString("company_ceo_name"));
                dto.setCompany_addr(rs.getString("company_addr"));
                dto.setCompany_found_date(rs.getString("company_found_date"));
                dto.setCompany_phone(rs.getString("company_phone"));
                dto.setCompany_account(rs.getString("company_account"));
             }
             
          }catch(Exception e) {
        	  e.printStackTrace();
          }finally {
             closeConn(rs, pstmt, con);
          }
          
          return dto;
       }	// getCompanyInfo() end.
      
      
      
      public ReqSellBoardDTO getReqSellBoardContent(int board_no) {
          
          ReqSellBoardDTO dto = null;
          
          try {
             openConn();
             
             sql = "select * from req_sell_board where req_sell_board_no = ?";
             
             pstmt = con.prepareStatement(sql);
             
             pstmt.setInt(1, board_no);
             
             rs = pstmt.executeQuery();
             
             if(rs.next()) {
                
                dto = new ReqSellBoardDTO();
                
                dto.setReq_sell_board_no(rs.getInt("req_sell_board_no"));
                dto.setReq_sell_board_user_no(rs.getString("req_sell_board_user_no"));
                dto.setReq_sell_board_car_std_no(rs.getString("req_sell_board_car_std_no"));
                dto.setReq_sell_board_car_no(rs.getString("req_sell_board_car_no"));
                dto.setReq_sell_board_car_distance(rs.getInt("req_sell_board_car_distance"));
                dto.setReq_sell_board_car_price(rs.getInt("req_sell_board_car_price"));
                dto.setReq_sell_board_car_detail(rs.getString("req_sell_board_car_detail"));
                dto.setReq_sell_board_date(rs.getString("req_sell_board_date"));
                dto.setReq_sell_board_update(rs.getString("req_sell_board_update"));
                dto.setReq_sell_board_car_file(rs.getString("req_sell_board_car_file"));
                dto.setReq_sell_board_status(rs.getBoolean("req_sell_board_status"));
             }
             
             
          }catch(Exception e) {
             e.printStackTrace();
          }finally {
             closeConn(rs, pstmt, con);
          }
          
          return dto;
       }
      
      
      // 관리자가 수정한 회사 정보를 DB에 업데이트 하는 매서드.
      public int updateCompanyInfo(CompanyDTO dto) {
    	  
    	  int result = 0;
    	 
    	  try {

        	openConn();
        	  
        	sql = "update company set company_name = ?, company_ceo_name = ?, company_addr = ?, "
        	  		+ "company_phone = ?, company_found_date = ?, company_account = ? where company_business_no = ?";
        	  
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, dto.getCompany_name());
			pstmt.setString(2, dto.getCompany_ceo_name());
			pstmt.setString(3, dto.getCompany_addr());
			pstmt.setString(4, dto.getCompany_phone());
			pstmt.setString(5, dto.getCompany_found_date());
			pstmt.setString(6, dto.getCompany_account());
			pstmt.setString(7, dto.getCompany_business_no());
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(pstmt, con);
		} 
    	  return result;
      }		// updateCompanyInfo(dto) end.
      
      

	      // 판매 요청 승인하여 판매 게시판에 글 추가하는 메서드
	   public int insertSellBoard(SellBoardDTO dto) {
	      
	      int result = 0, count = 0;
	      
	      try {
	         openConn();
	         
	         sql = "select max(sell_board_no) from sell_board";
	         
	         pstmt = con.prepareStatement(sql);
	         
	         rs = pstmt.executeQuery();
	         
	         if(rs.next()) {
	            count = rs.getInt(1) + 1;
	         }
	         
	         sql = "insert into sell_board values(?, ?, ?, ?, ?, ?, ?, ?, default, null, ?, default)";
	         
	         pstmt = con.prepareStatement(sql);
	         pstmt.setInt(1, count);
	         pstmt.setString(2, dto.getSell_board_admin_no());
	         pstmt.setString(3, dto.getSell_board_seller_no());
	         pstmt.setString(4, dto.getSell_board_car_std_no());
	         pstmt.setString(5, dto.getSell_board_car_no());
	         pstmt.setInt(6, dto.getSell_board_car_distance());
	         pstmt.setInt(7, dto.getSell_board_car_price());
	         pstmt.setString(8, dto.getSell_board_car_detail());
	         pstmt.setString(9, dto.getSell_board_car_file());
	         
	         result = pstmt.executeUpdate();
	         
	      }catch(Exception e) {
	         e.printStackTrace();
	      }finally {
	         closeConn(rs, pstmt, con);
	      }
	      
	      return result;
	   }	// insertSellBoard(dto) end.
	
	   
	   // 판매 요청 게시판 상태를 변경하는 메서드
	   public void changeReqSellBoardStatus(int board_no) {
	      
	      try {
	         openConn();
	         
	         sql = "update req_sell_board set req_sell_board_status = true where req_sell_board_no = ?";
	         
	         pstmt = con.prepareStatement(sql);
	         pstmt.setInt(1, board_no);
	         
	         pstmt.executeUpdate();
	         
	      }catch(Exception e) {
	         e.printStackTrace();
	      }finally {
	         closeConn(pstmt, con);
	      }
	      
	   }	// changeReqSellBoardStatus() end.
      
	   
	   
	   // qna 글 삽입 메서드
	   public int insertQna(QnaBoardDTO dto) {
	      
	      int result = 0, cnt = 0;
	      
	      try {
	         openConn();
	         
	         sql = "select max(qna_board_no) from qna_board";
	         
	         pstmt = con.prepareStatement(sql);
	         
	         rs = pstmt.executeQuery();
	         
	         if(rs.next()) {
	            cnt = rs.getInt(1) + 1;
	         }
	         
	         sql = "insert into qna_board values(?, ?, ?, ?, ?, default, null, ?)";
	         
	         pstmt = con.prepareStatement(sql);
	         pstmt.setInt(1, cnt);
	         pstmt.setString(2, dto.getQna_board_type());
	         pstmt.setString(3, dto.getQna_board_writer_id());
	         pstmt.setString(4, dto.getQna_board_title());
	         pstmt.setString(5, dto.getQna_board_cont());
	         pstmt.setString(6, dto.getQna_board_file());
	         
	         result = pstmt.executeUpdate();
	         
	      }catch(Exception e) {
	         e.printStackTrace();
	      }finally {
	         closeConn(rs, pstmt, con);
	      }
	      
	      return result;
	   }	// insertQna(dto) end.
	      
	   
	   public void fkCheckOn() {	// 무결성검사 시 외래키 검사하는 설정 켜기
		   
			   try {
				   
				sql = "set foreign_key_checks = 1";
				   
				pstmt = con.prepareStatement(sql);
				
				pstmt.executeUpdate();
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
	   }
	   
	   public void fkCheckOff() {	// 무결성검사 시 외래키 검사하는 설정 끄기
		   
		   try {
			   
			sql = "set foreign_key_checks = 0";
			   
			pstmt = con.prepareStatement(sql);
			
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
   }
	   
	   
	   // 유저 회원탈퇴를 하는 매서드.
	   public int deleteUser(String user_no) {	
		   
		   int result = 0;
		   
			   try {
	
			   openConn();
			   
			   fkCheckOff();
			   
			   sql = "delete from user where user_no = ?";
			   
			   pstmt = con.prepareStatement(sql);
			   
			   pstmt.setString(1, user_no);
			   
			   result = pstmt.executeUpdate();
			   
			   fkCheckOn();
			   
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeConn(pstmt, con);
			}
			   
		  return result;
	   }	// deleteUser(user_no) end.
      
	   
	   // 관리자가 공지사항을 등록하는 매서드.
	   public int insertNotice(NoticeBoardDTO dto) {
		   
		   int result = 0, cnt = 0;
		   
		   try {

			   openConn();
			   
			   sql = "select max(notice_board_no) from notice_board";
			   
			   pstmt = con.prepareStatement(sql);
			   
			   rs = pstmt.executeQuery();
			   
			   if(rs.next()) {
				   cnt = rs.getInt(1) + 1;
			   }
			   
			   sql = "insert into notice_board values(?, ?, ?, ?, default, null, default, ?)";
			   
			   pstmt = con.prepareStatement(sql);
			   
			   pstmt.setInt(1, cnt);
			   pstmt.setString(2, dto.getNotice_board_writer_id());
			   pstmt.setString(3, dto.getNotice_board_title());
			   pstmt.setString(4, dto.getNotice_board_cont());
			   pstmt.setString(5, dto.getNotice_board_file());
			   
			   result = pstmt.executeUpdate();
			   
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		   
		   return result;
	   }	// insertNotice(dto) end.
	   
	   
	   // 	공지사항의 갯수를 카운트하는 매서드.
	   public int countNoticeList() {
		   
		   int cnt = 0;

		   try {

			   openConn();
			   
			   sql = "select count(*) from notice_board";
			   
			   pstmt = con.prepareStatement(sql);
			   
			   rs = pstmt.executeQuery();
			   
			   if(rs.next()) {
				   cnt = rs.getInt(1);
			   }
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		   
		   return cnt;
	   }	// countNoticeList() end.
	   
	   
	   
	   // 공지사항의 모든 글을 읽어오는 매서드.
	   public List<NoticeBoardDTO> getNoticeList(){
		   
		   List<NoticeBoardDTO> list = new ArrayList<NoticeBoardDTO>();
		   
		   try {

			   NoticeBoardDTO dto = null;
			   
			   openConn();
			   
			   sql = "select * from notice_board order by notice_board_no desc";
			   
			   pstmt = con.prepareStatement(sql);
			   
			   rs = pstmt.executeQuery();
			   
			   while(rs.next()) {
				   
				   dto = new NoticeBoardDTO();
				   
				   dto.setNotice_board_no(rs.getInt("notice_board_no"));
				   dto.setNotice_board_writer_id(rs.getString("notice_board_writer_id"));
				   dto.setNotice_board_title(rs.getString("notice_board_title"));
				   dto.setNotice_board_cont(rs.getString("notice_board_cont"));
				   dto.setNotice_board_date(rs.getString("notice_board_date"));
				   dto.setNotice_board_update(rs.getString("notice_board_update"));
				   dto.setNotice_board_hit(rs.getInt("notice_board_hit"));
				   dto.setNotice_board_file(rs.getString("notice_board_file"));
				   
				   list.add(dto);
				   
			   }
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		   
		   return list;
	   }	// getNoticeList() end.
	   
	   
	   // 관리자가 이벤트를 등록하는 매서드.
	   public int insertEvent(EventBoardDTO dto) {
		   int result = 0, cnt = 0;
		   
		   try {

			   openConn();
			   
			   sql = "select max(event_board_no) from event_board";
			   
			   pstmt = con.prepareStatement(sql);
			   
			   rs = pstmt.executeQuery();
			   
			   if(rs.next()) {
				   cnt = rs.getInt(1) + 1;
			   }
			   
			   sql = "insert into event_board values(?, ?, ?, ?, default, null, default, ?)";
			   
			   pstmt = con.prepareStatement(sql);
			   
			   pstmt.setInt(1, cnt);
			   pstmt.setString(2, dto.getEvent_board_writer_id());
			   pstmt.setString(3, dto.getEvent_board_title());
			   pstmt.setString(4, dto.getEvent_board_cont());
			   pstmt.setString(5, dto.getEvent_board_file());
			   
			   result = pstmt.executeUpdate();
			   
		} catch (SQLException e) {
			e.printStackTrace();
		}	finally {
			closeConn(rs, pstmt, con);
		}
		   
		   return result;
	   }	// insertEvent(dto) end.
	   
	   
	   // 	이벤트의 갯수를 카운트하는 매서드.
	   public int countEventList() {
		   
		   int cnt = 0;

		   try {

			   openConn();
			   
			   sql = "select count(*) from event_board";
			   
			   pstmt = con.prepareStatement(sql);
			   
			   rs = pstmt.executeQuery();
			   
			   if(rs.next()) {
				   cnt = rs.getInt(1);
			   }
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		   
		   return cnt;
	   }	// countEventList() end.
	   
	   
	   
	   // 이벤트의 모든 글을 읽어오는 매서드.
	   public List<EventBoardDTO> getEventList(){
		   
		   List<EventBoardDTO> list = new ArrayList<EventBoardDTO>();
		   
		   try {

			   EventBoardDTO dto = null;
			   
			   openConn();
			   
			   sql = "select * from event_board order by event_board_no desc";
			   
			   pstmt = con.prepareStatement(sql);
			   
			   rs = pstmt.executeQuery();
			   
			   while(rs.next()) {
				   
				   dto = new EventBoardDTO();
				   
				   dto.setEvent_board_no(rs.getInt("event_board_no"));
				   dto.setEvent_board_writer_id(rs.getString("event_board_writer_id"));
				   dto.setEvent_board_title(rs.getString("event_board_title"));
				   dto.setEvent_board_cont(rs.getString("event_board_cont"));
				   dto.setEvent_board_date(rs.getString("event_board_date"));
				   dto.setEvent_board_update(rs.getString("event_board_update"));
				   dto.setEvent_board_hit(rs.getInt("event_board_hit"));
				   dto.setEvent_board_file(rs.getString("event_board_file"));
				   
				   list.add(dto);
				   
			   }
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		   
		   return list;
	   }	// getEventList() end.
	   
	   
	   
	   
}	// class end.
