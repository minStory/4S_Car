-- 회사 정보 테이블
create table company(
   company_business_no varchar(50) primary key,            -- 사업자번호(123-45-67890)
    company_name varchar(50) not null,                     -- 회사명(4Scar)
    company_ceo_name varchar(50) not null,                  -- 대표이사
    company_addr varchar(50),                           -- 주소(충청남도 천안시 서북구 불당22대로 92 7층)
    company_phone varchar(50),                           -- 전화번호(1588-5530)
    company_found_date date,                           -- 설립일(20220501)
    company_account varchar(50) unique not null               -- 계좌번호(농협은행 352-1588-5530-99)
);


-- 관리자 정보 테이블
create table admin(
   admin_no varchar(50) primary key,                     -- 관리자번호 ex)A001
    admin_id varchar(50) unique key not null,              -- ID(admin01, admin02, admin03, admin04)
    admin_pwd varchar(50) not null,                        -- 비밀번호(1234)
    admin_name varchar(50) not null,                     -- 성명
    admin_job varchar(50) not null,                        -- 직책(ceo, site_manager, dealer)
    admin_phone varchar(50) not null                     -- 전화번호
);

-- 회원 정보 테이블
create table user(
   user_no varchar(50) primary key,                     -- 회원번호 ex)U20240318001
    user_id varchar(50) unique key not null,                        -- ID
    user_pwd varchar(50) not null,                        -- 비밀번호
    user_name varchar(50) not null,                        -- 성명
    user_phone varchar(50) not null,                     -- 전화번호
    user_email varchar(50) not null,                     -- 이메일
    user_mileage int default 0,                           -- 마일리지
    user_grade varchar(50) default "bronze",                  -- 회원등급
    user_regdate datetime default now()               -- 가입일
);

-- 차량 스펙 테이블
create table car(
    car_manufact_company varchar(50) not null,               -- 제조사
    car_manufact_year int not null,                        -- 연식
    car_type varchar(50) not null,                        -- 종류
    car_fuel varchar(50) not null,                        -- 연료
    car_color varchar(50) not null,                        -- 색상
    car_transmission varchar(50) not null,               -- 변속기
    car_model varchar(50) not null                     -- 차량모델
);

-- 차량 판매 요청 게시판(user -> admin)                                                                                                                                                                                                                                                                                                                                                
create table req_sell_board(
    req_sell_board_no int primary key,                     -- 글번호
    req_sell_board_user_no varchar(50) not null,            -- 요청자 회원번호
    req_sell_board_car_std_no varchar(50) not null,            -- 요청차량 구분번호(차량 스펙 조인)
    req_sell_board_car_no varchar(50) unique not null,         -- 차량번호
    req_sell_board_car_distance int not null,               -- 주행거리
    req_sell_board_car_price int not null,                  -- 가격
    req_sell_board_car_detail varchar(2000) not null,         -- 차량 상세 정보(딜러에게 정보 제공)
    req_sell_board_date datetime not null default now(),      -- 요청일자
    req_sell_board_update datetime,                        -- 수정일자
    req_sell_board_car_file varchar(2000),                     -- 업로드 파일 저장 경로
    req_sell_board_status boolean not null default false,   -- 요청 승인 상태    
    
    foreign key (req_sell_board_user_no) references user (user_no) on update cascade
);

-- 차량 판매 게시판(admin)
create table sell_board(
    sell_board_no int primary key,                        -- 글번호
    sell_board_admin_no varchar(50) not null,               -- 관리자번호(딜러 정보 조인)
    sell_board_seller_no varchar(50) default null,          -- 판매자 회원번호(구매이력 조인)
    sell_board_car_std_no varchar(50) not null,               -- 등록차량 구분번호(차량 스펙 조인)
    sell_board_car_no varchar(50) not null,                  -- 차량번호(회원 요청 사항 조인)
    sell_board_car_distance int not null,               -- 차량 주행거리
    sell_board_car_price int not null,                  -- 가격
    sell_board_car_detail varchar(2000) not null,            -- 차량 상세 정보(홍보 내용)
    sell_board_date datetime not null default now(),         -- 등록일자
    sell_board_update datetime,                           -- 수정일자
    sell_board_car_file varchar(2000),                        -- 업로드 파일 저장 경로
    sell_board_status boolean not null default false,      -- 판매 상태
    
    
    foreign key (sell_board_admin_no) references admin (admin_no) on update cascade,
    foreign key (sell_board_seller_no) references user (user_no) on update cascade,
    foreign key (sell_board_car_no) references req_sell_board (req_sell_board_car_no) on update cascade on delete cascade
);


-- 차량 거래 이력 테이블
create table transaction(
   transaction_no int primary key,                     -- 거래번호
   transaction_seller_no varchar(50) not null,            -- 판매자 번호
   transaction_buyer_no varchar(50) not null,            -- 구매자 번호
   transaction_dealer_no varchar(50) not null,          -- 딜러 번호
   transaction_car_std_no varchar(50) not null,         -- 거래 차량 구분번호
   transaction_car_no varchar(50) not null,            -- 거래 차량번호
   transaction_car_distance int not null,                -- 거래 차량 주행거리
    transaction_car_price int not null,                  -- 가격
   transaction_date datetime not null default now(),      -- 거래일자
   
   foreign key (transaction_seller_no) references user (user_no) on update cascade,
   foreign key (transaction_buyer_no) references user (user_no) on update cascade,
   foreign key (transaction_dealer_no) references admin (admin_no) on update cascade
);

-- 찜 목록 테이블
create table favorite(
    favorite_no int primary key,                        -- 찜목록 번호
    favorite_user_no varchar(50) not null,                  -- 찜한 회원번호
    favorite_sell_board_no int not null,                  -- 찜한 차량 판매 글번호
    
    foreign key (favorite_user_no) references user (user_no) on update cascade,
    foreign key (favorite_sell_board_no) references sell_board (sell_board_no) on delete cascade on update cascade
);

-- 결제 테이블
create table payment(
    payment_no varchar(50) primary key,                     -- 결제번호 ex)P20230318001
    payment_method varchar(50) not null,                  -- 결제방식(현금, 카드)
    payment_account varchar(50) not null,                  -- 입금계좌(company 테이블 조인)
    payment_card_company varchar(50),                     -- 카드사(카드결제 선택 시 not null)
    payment_card_no varchar(50),                        -- 카드번호(카드결제 선택 시 not null)
    payment_card_div_month int,                           -- 할부개월수(0~12)(카드결제 선택 시 not null)
    payment_card_pwd varchar(50),                        -- 카드 비밀번호(카드결제 선택 시 not null)
    payment_amount int not null,                        -- 결제금액
    
    foreign key (payment_account) references company (company_account) on update cascade
);

-- 판매 후기 게시판 테이블
create table sell_review_board(
   sell_review_board_no int primary key,                  -- 글번호
    sell_review_board_writer_id varchar(50) not null,            -- 작성자
    sell_review_board_title varchar(50) not null,            -- 제목
    sell_review_board_cont varchar(50) not null,            -- 내용
    sell_review_board_date datetime not null default now(),      -- 등록일시
    sell_review_board_update datetime,                     -- 수정일시
    sell_review_board_hit int                           -- 조회수
);

-- 자유 게시판 테이블
create table community_board(
   community_board_no int primary key,                     -- 글번호
    community_board_writer_id varchar(50) not null,            -- 작성자
    community_board_title varchar(50) not null,               -- 제목
    community_board_cont varchar(50) not null,               -- 내용
    community_board_date datetime not null default now(),      -- 등록일시
    community_board_update datetime,                     -- 수정일시
    community_board_hit int                              -- 조회수
);

-- 구매 후기 게시판 테이블
create table buy_review_board(
   buy_review_board_no int primary key,                  -- 글번호
    buy_review_board_writer_id varchar(50) not null,            -- 작성자
    buy_review_board_title varchar(50) not null,            -- 제목
    buy_review_board_cont varchar(50) not null,               -- 내용
    buy_review_board_date datetime not null default now(),      -- 등록일시
    buy_review_board_update datetime,                     -- 수정일시
    buy_review_board_hit int                           -- 조회수
);

create table qna_board(
	qna_board_no int primary key,						-- 글번호
	qna_board_type varchar(50) not null,				-- 문의 유형
    qna_board_writer_id varchar(50) not null,			-- 작성자
    qna_board_title varchar(50) not null,				-- 제목
    qna_board_cont varchar(50) not null,				-- 내용
    qna_board_date datetime not null default now(),		-- 게시일자
    qna_board_update datetime,							-- 수정일자
    qna_board_file varchar(2000)						-- 업로드 파일
);

create table notice_board(
	notice_board_no int primary key,						-- 글번호
    notice_board_writer_id varchar(50) not null,			-- 작성자
    notice_board_title varchar(50) not null,				-- 제목
    notice_board_cont varchar(50) not null,					-- 내용
    notice_board_date datetime not null default now(),		-- 게시일자
    notice_board_update datetime,							-- 수정일자
    notice_board_hit int default 0,							-- 조회수
    notice_board_file varchar(2000)							-- 업로드 파일
);

create table event_board(
	event_board_no int primary key,							-- 글번호
    event_board_writer_id varchar(50) not null,				-- 작성자
    event_board_title varchar(50) not null,					-- 제목
    event_board_cont varchar(50) not null,					-- 내용
    event_board_date datetime not null default now(),		-- 게시일자
    event_board_update datetime,							-- 수정일자
    event_board_hit int default 0,							-- 조회수
    event_board_file varchar(2000)							-- 업로드 파일
);

insert into admin values("A001", "admin01", "1234", "박성민", "ceo", "010-0000-0000");
insert into admin values("A002", "admin02", "1234", "길호성", "site_manager", "010-0000-0000");
insert into admin values("A003", "admin03", "1234", "이솔", "dealer", "010-0000-0000");
insert into admin values("A004", "admin04", "1234", "구연서", "dealer", "010-0000-0000");

insert into company values("123-45-67890", "(주)4Scar", "박성민", "충청남도 천안시 서북구 불당22대로 92 7층", "1588-5530", "20220501", "농협은행 352-1588-5530-99");

commit;