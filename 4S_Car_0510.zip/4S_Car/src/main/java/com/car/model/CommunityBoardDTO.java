package com.car.model;

public class CommunityBoardDTO {

	private int community_board_no;
	private String community_board_writer_id;
	private String community_board_title;
	private String community_board_cont;
	private String community_board_date;
	private String community_board_update;
	private int community_board_hit;

	public int getCommunity_board_no() {
		return community_board_no;
	}

	public void setCommunity_board_no(int community_board_no) {
		this.community_board_no = community_board_no;
	}

	public String getCommunity_board_writer_id() {
		return community_board_writer_id;
	}

	public void setCommunity_board_writer_id(String community_board_writer_id) {
		this.community_board_writer_id = community_board_writer_id;
	}

	public String getCommunity_board_title() {
		return community_board_title;
	}

	public void setCommunity_board_title(String community_board_title) {
		this.community_board_title = community_board_title;
	}

	public String getCommunity_board_cont() {
		return community_board_cont;
	}

	public void setCommunity_board_cont(String community_board_cont) {
		this.community_board_cont = community_board_cont;
	}

	public String getCommunity_board_date() {
		return community_board_date;
	}

	public void setCommunity_board_date(String community_board_date) {
		this.community_board_date = community_board_date;
	}

	public String getCommunity_board_update() {
		return community_board_update;
	}

	public void setCommunity_board_update(String community_board_update) {
		this.community_board_update = community_board_update;
	}

	public int getCommunity_board_hit() {
		return community_board_hit;
	}

	public void setCommunity_board_hit(int community_board_hit) {
		this.community_board_hit = community_board_hit;
	}
}
