package com.car.action;

public class StaticArea {
	
	// 날짜 정보 month를 2자리로 맞추기 위한 메서드
	   public static String getMonth(int month) {
	      if(month < 10) {
	         return "0" + String.valueOf(month);
	      }else {
	         return String.valueOf(month);
	      }
	   }
	   
	   // 날짜 정보 day를 2자리로 맞추기 위한 메서드
	   public static String getDay(int day) {
	      if(day < 10) {
	         return "0" + String.valueOf(day);
	      }else {
	         return String.valueOf(day);
	      }
	   }
	   
	// 마일리지 상태에 따라 유저 등급 나눠주는 메서드
	      public static String getUserGrade(int mileage) {
	         String grade = "bronze";
	         
	         if(mileage >= 300000) {
	            grade = "platinum";
	         }else if(mileage >= 200000){
	            grade = "gold";
	         }else if(mileage >= 100000) {
	            grade = "silver";
	         }
	         
	         return grade;
	      }
	
}
