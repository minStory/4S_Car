package com.car.action.boards;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.model.SellReviewBoardDTO;
import com.car.model.TotalDAO;

public class SellReviewBoardListAction implements Action{

   @Override
   public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
      TotalDAO dao = TotalDAO.getInstance();
      
      int count = dao.countSellReviewBoardList();
      
      List<SellReviewBoardDTO> list = dao.getSellReviewList();
      
      request.setAttribute("cnt", count);
      request.setAttribute("list", list);
      
      
      ActionForward forward = new ActionForward();
      
      forward.setPath("/WEB-INF/views/public/boards/sell_review_board_list.jsp");
      
      return forward;
   }

}