package com.car.action.search;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.model.SellBoardDTO;
import com.car.model.TotalDAO;

public class CarListAction implements Action{

   @Override
   public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
      TotalDAO dao = TotalDAO.getInstance();
         
       List<SellBoardDTO> list = dao.getSellBoard();
       
       List<String> typeList = new ArrayList<>(
             Arrays.asList("경차", "소형", "중형", "대형", "스포츠", "SUV", "승합", "화물")
       );
       
       List<String> companyList = new ArrayList<>(
             Arrays.asList("현대", "제네시스", "기아", "쉐보레", "르노코리아", "대우", "쌍용",
                   "벤츠", "bmw", "아우디", "폭스바겐", "미니", "볼보", "폴스타", "포르쉐", "도요타")
       );
       List<Integer> companyCountList = dao.getCountCompany(companyList);
       
       List<String> fuelList = new ArrayList<>(
             Arrays.asList("가솔린", "디젤", "LPG", "전기", "하이브리드")
       );
       
       int count = dao.getAllCarList();
       request.setAttribute("allCount", count);
       
       request.setAttribute("list", list);
       request.setAttribute("typeList", typeList);
       request.setAttribute("companyList", companyList);
       request.setAttribute("companyCountList", companyCountList);
       request.setAttribute("fuelList", fuelList);
      
      ActionForward forward = new ActionForward();
      
      forward.setPath("/WEB-INF/views/public/search/car_list.jsp");
      
      return forward;
   }

}