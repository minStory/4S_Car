package com.car.action.mypage;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.model.QnaBoardDTO;
import com.car.model.TotalDAO;

public class MyReviewAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		TotalDAO dao = TotalDAO.getInstance();
		
		int cnt = dao.countQnaList();
		
		List<QnaBoardDTO> list = dao.getQnaBoardList();
		
		Collections.reverse(list);
		
		request.setAttribute("qna_cnt", cnt);
		request.setAttribute("qna_list", list);
		
		ActionForward forward = new ActionForward();
		
		forward.setPath("/WEB-INF/views/public/mypage/my_review.jsp");
		
		return forward;
	}

}
