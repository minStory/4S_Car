package com.car.model;

public class SellReviewBoardDTO {

	private int sell_review_board_no;
	private String sell_review_board_writer_id;
	private String sell_review_board_title;
	private String sell_review_board_cont;
	private String sell_review_board_date;
	private String sell_review_board_update;
	private int sell_review_board_hit;
	
	public int getSell_review_board_no() {
		return sell_review_board_no;
	}
	public void setSell_review_board_no(int sell_review_board_no) {
		this.sell_review_board_no = sell_review_board_no;
	}
	public String getSell_review_board_writer_id() {
		return sell_review_board_writer_id;
	}
	public void setSell_review_board_writer_id(String sell_review_board_writer_id) {
		this.sell_review_board_writer_id = sell_review_board_writer_id;
	}
	public String getSell_review_board_title() {
		return sell_review_board_title;
	}
	public void setSell_review_board_title(String sell_review_board_title) {
		this.sell_review_board_title = sell_review_board_title;
	}
	public String getSell_review_board_cont() {
		return sell_review_board_cont;
	}
	public void setSell_review_board_cont(String sell_review_board_cont) {
		this.sell_review_board_cont = sell_review_board_cont;
	}
	public String getSell_review_board_date() {
		return sell_review_board_date;
	}
	public void setSell_review_board_date(String sell_review_board_date) {
		this.sell_review_board_date = sell_review_board_date;
	}
	public String getSell_review_board_update() {
		return sell_review_board_update;
	}
	public void setSell_review_board_update(String sell_review_board_update) {
		this.sell_review_board_update = sell_review_board_update;
	}
	public int getSell_review_board_hit() {
		return sell_review_board_hit;
	}
	public void setSell_review_board_hit(int sell_review_board_hit) {
		this.sell_review_board_hit = sell_review_board_hit;
	}
	
}
