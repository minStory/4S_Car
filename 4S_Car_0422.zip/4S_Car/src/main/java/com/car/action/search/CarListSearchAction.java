package com.car.action.search;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.action.StaticArea;
import com.car.model.SellBoardDTO;
import com.car.model.TotalDAO;

public class CarListSearchAction implements Action{

   @Override
   public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {
      
      String filter = null;
      if(request.getParameter("filter") != null) {
         filter = request.getParameter("filter");
      }
      String keyword = request.getParameter("keyword");
      
      List<SellBoardDTO> list = null;
      
      TotalDAO dao = TotalDAO.getInstance();
      if(filter == null) {
         list = dao.keywordSearch(keyword);
      }else {
         list = dao.keywordSearch(filter, keyword);
      }
        
      List<Integer> companyCountList = dao.getCountCompany(StaticArea.getCompanyList());
      
      int allCount = dao.getCarListAllCount();
      int count = list.size();
      request.setAttribute("allCount", allCount);
      request.setAttribute("count", count);
      request.setAttribute("list", list);
      request.setAttribute("typeList", StaticArea.getTypeList());
      request.setAttribute("companyList", StaticArea.getCompanyList());
      request.setAttribute("companyCountList", companyCountList);
      request.setAttribute("colorList", StaticArea.getColorList());
      request.setAttribute("fuelList", StaticArea.getFuelList());
      request.setAttribute("transmissionList", StaticArea.getTransmissionList());
      request.setAttribute("filterList", StaticArea.getFilterList());
      request.setAttribute("sequenceList", StaticArea.getSequenceList());
      
      ActionForward forward = new ActionForward();
      
      forward.setPath("/WEB-INF/views/public/search/car_list.jsp");
      
      return forward;
   }
}