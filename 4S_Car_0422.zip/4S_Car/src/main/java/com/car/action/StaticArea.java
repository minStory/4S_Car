package com.car.action;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StaticArea {
   
      // jsp 파일에서 반복적으로 사용될 리스트
      public static List<String> companyList = new ArrayList<>(
               Arrays.asList("현대", "제네시스", "기아", "쉐보레", "르노코리아", "대우", "쌍용",
                     "벤츠", "bmw", "아우디", "폭스바겐", "미니", "볼보", "폴스타", "포르쉐", "도요타")
         );
       
       public static List<String> typeList = new ArrayList<>(
               Arrays.asList("경차", "소형", "중형", "대형", "스포츠", "SUV", "승합", "화물")
         );
       
       public static List<String> fuelList = new ArrayList<>(
               Arrays.asList("가솔린", "디젤", "LPG", "전기", "하이브리드")
         );
         
       public static List<String> filterList = new ArrayList<>(
                Arrays.asList("전체", "제조사", "차종", "연료", "색상", "모델명")
         );
       
       public static List<String> transmissionList = new ArrayList<>(
             Arrays.asList("자동", "수동")
        );
       
       public static List<String> colorList = new ArrayList<>(
             Arrays.asList("흰색", "검정색", "회색", "은색", "빨간색", "파란색")
        );
       
       public static List<String> sequenceList = new ArrayList<>(
             Arrays.asList("최근 연식순", "오래된 연식순", "적은 주행거리순", "많은 주행거리순")
        );

      public static List<String> getCompanyList() {
         return companyList;
      }

      public static List<String> getTypeList() {
         return typeList;
      }
      
      public static List<String> getFuelList() {
         return fuelList;
      }

      public static List<String> getFilterList() {
         return filterList;
      }

      public static List<String> getTransmissionList() {
         return transmissionList;
      }

      public static List<String> getColorList() {
         return colorList;
      }

      public static List<String> getSequenceList() {
         return sequenceList;
      }

   // 날짜 정보 month를 2자리로 맞추기 위한 메서드
      public static String getMonth(int month) {
         if(month < 10) {
            return "0" + String.valueOf(month);
         }else {
            return String.valueOf(month);
         }
      }
      
      // 날짜 정보 day를 2자리로 맞추기 위한 메서드
      public static String getDay(int day) {
         if(day < 10) {
            return "0" + String.valueOf(day);
         }else {
            return String.valueOf(day);
         }
      }
      
   // 마일리지 상태에 따라 유저 등급 나눠주는 메서드
         public static String getUserGrade(int mileage) {
            String grade = "bronze";
            
            if(mileage >= 300000) {
               grade = "platinum";
            }else if(mileage >= 200000){
               grade = "gold";
            }else if(mileage >= 100000) {
               grade = "silver";
            }
            
            return grade;
         }
}