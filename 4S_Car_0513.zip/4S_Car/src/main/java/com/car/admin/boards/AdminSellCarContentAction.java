package com.car.admin.boards;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.action.StaticArea;
import com.car.model.AdminDTO;
import com.car.model.ReqSellBoardDTO;
import com.car.model.TotalDAO;

public class AdminSellCarContentAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
				
		
		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/admin/boards/sell_car_content.jsp");

		return forward;
	}

}
