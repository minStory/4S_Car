function checkSessionStatus() {
	
    $.ajax({
        url: 'check_session_status', // 세션 확인을 처리하는 서버 측 URL
        success: function(response) {
            if (response === "expired") {
                alert("세션이 만료되어 로그아웃 합니다.");
                window.location.href = 'main.jsp'; // 만료 시 리다이렉트할 페이지
            }
        }
    });
}

$(document).ready(function() {
    setInterval(checkSessionStatus, 60000); // 1분(60초)마다 함수 호출
});