package com.car.action.customer;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.model.EventBoardDTO;
import com.car.model.NoticeBoardDTO;
import com.car.model.TotalDAO;

public class NoticeListAction implements Action{

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		TotalDAO dao = TotalDAO.getInstance();
		
		int notice_cnt = dao.countNoticeList();
		
		List<NoticeBoardDTO> notice_list = dao.getNoticeList();
		
		int event_cnt = dao.countEventList();
		
		List<EventBoardDTO> event_list = dao.getEventList();
		
		request.setAttribute("notice_cnt", notice_cnt);
		request.setAttribute("notice_list", notice_list);
		
		request.setAttribute("event_cnt", event_cnt);
		request.setAttribute("event_list", event_list);
		
		ActionForward forward = new ActionForward();
		
		forward.setPath("/WEB-INF/views/public/customer/notice_list.jsp");
		
		return forward;
	}

}
