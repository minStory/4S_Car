package com.car.action.search;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.model.SellBoardDTO;
import com.car.model.TotalDAO;

public class CarListAction implements Action{

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		TotalDAO dao = TotalDAO.getInstance();
	      
	    List<SellBoardDTO> list = dao.getSellBoard();
	      
	    request.setAttribute("list", list);
		
		ActionForward forward = new ActionForward();
		
		forward.setPath("/WEB-INF/views/public/search/car_list.jsp");
		
		return forward;
	}

}
