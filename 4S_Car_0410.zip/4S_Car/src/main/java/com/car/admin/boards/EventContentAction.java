package com.car.admin.boards;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.model.EventBoardDTO;
import com.car.model.TotalDAO;

public class EventContentAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		int event_no = Integer.parseInt(request.getParameter("no").trim());
		
		TotalDAO dao = TotalDAO.getInstance();
		
		return null;
	}

}
