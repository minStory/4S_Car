package com.car.admin.usermanagement;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.model.TotalDAO;
import com.car.model.UserDTO;

public class UserListAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		  TotalDAO dao = TotalDAO.getInstance();
	      List<UserDTO> list = dao.getUserList();
	      
	      request.setAttribute("list", list);
	   
	      ActionForward forward = new ActionForward();
	      
	      forward.setPath("/WEB-INF/views/admin/usermanagement/user_list.jsp");
	      
	      return forward;
      }
}
