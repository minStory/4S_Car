function openTab(evt, tabName) {
    var i, tabcontent, tablinks;

    // 모든 탭 내용을 숨김
    tabcontent = document.getElementsByClassName("tab-item");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    // 모든 탭 버튼의 활성화 상태 제거
    tablinks = document.getElementsByClassName("tab-item");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].classList.remove("active");
    }

    // 해당 탭 내용을 표시하고, 탭 버튼을 활성화 상태로 변경
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.parentElement.classList.add("active");

    // // 모든 선을 숨김
    // var allBars = document.querySelectorAll('.bar');
    // allBars.forEach(function(bar) {
    //     bar.style.display = "none";

    // });

    // var bar = evt.currentTarget.parentElement.querySelector('.bar');
    // if(bar) {
    //     bar.style.display = "block";
    // }

    

   
}

// 페이지 로드 시 초기 설정
document.addEventListener("DOMContentLoaded", function(event) {
    var eventBar = document.querySelector('.event-bar');
    var noticeBar = document.querySelector('.notice-bar');
    var tabBtn1 = document.querySelector('.tab-item-1');
    var tabBtn2 = document.querySelector('.tab-item-2');
    
    // 초기에 공지사항 버튼이 선택되어 있으므로 빨간선이 있고, 이벤트 버튼 아래에는 회색선이 있도록 설정
    noticeBar.style.display = "block";
    noticeBar.style.backgroundColor = "#ff0000"; // 빨간색
    eventBar.style.display = "block";
    eventBar.style.backgroundColor = "#cccccc"; // 회색

    // 이벤트 리스너 등록
    tabBtn1.addEventListener('click', function() {
        // 공지사항 버튼을 클릭하면 빨간선 표시, 이벤트 버튼 아래에 회색선 표시
        noticeBar.style.display = "block";
        noticeBar.style.backgroundColor = "#ff0000"; // 빨간색
        eventBar.style.display = "block";
        eventBar.style.backgroundColor = "#cccccc"; // 회색
    });

    tabBtn2.addEventListener('click', function() {
        // 이벤트 버튼을 클릭하면 빨간선 표시, 공지사항 버튼 아래에 회색선 표시
        noticeBar.style.display = "block";
        noticeBar.style.backgroundColor = "#cccccc"; // 회색
        eventBar.style.display = "block";
        eventBar.style.backgroundColor = "#ff0000"; // 빨간색
    });
});



function moveLine(tabBtn) {
    var bar = tabBtn.querySeletor('.bar');
    var tabBtn = document.querySelector('.tab-btns');

    bar.style.left = tabBtn.offsetLeft + 'px';
}

document.querySelectorAll('.tab-btns li').forEach(function(tabBtn){
    tabBtn.addEventListener('click', function(){
        moveLine(tabBtn);
    });
});

window.addEventListener('load', function() {
    var initialTabBtn = document.querySelector('.tab-btns li');
    moveLine(initialTabBtn);
});