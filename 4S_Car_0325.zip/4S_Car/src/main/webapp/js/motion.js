
$(function(){

    var carSell = $(".car_sell");

    var carBuy = $(".car_sell");

    var myPage = $(".car_sell");

    var comunity = $(".car_sell");
    
    var gongji = $(".gongju");


    var menual_1 = $("lnb1");

    var menual_2 = $("lnb2");

    var menual_3 = $("lnb3");

    var menual_4 = $("lnb4");

    var menual_5 = $("lnb5");
   
 
   
        $(".scroll_top").click(function(){
            $("html").animate({ scrollTop: 0 });
        })
        
   });
   
   
   
$(document).ready(function() {

    $.ajax({
        type: "POST",
        url: "check_login_status",
        success: function(response) {
            if (response.loggedIn == 1) {
            
                // 유저 로그인 상태일 경우
                $('.login_main').hide(); // 로그인 버튼 숨기기
                $('#admin_btn').hide(); // 관리자 로그인 버튼 숨기기
                $('.logout').show();
                $('#user_name').html('<a href="mypage">' + response.username + '</a> 님');
                $('#user_name').show();
                
                // 사용자 번호도 함께 받아오기
                var userno = response.userno;
            } else if(response.loggedIn == 0){
            
            	// 관리자 로그인 상태일 경우
                $('.login_main').hide();    // 로그인 버튼 숨기기
                $('#admin_btn').hide();     // 관리자 로그인 버튼 숨기기
                $('#admin_page_btn').show(); // 관리자 페이지 버튼 보이기
                $('.logout').show();
                $('#user_name').html('<a href="admin_main">' + response.adminname + '</a> 님');
                $('#user_name').show();
                
                // 사용자 번호도 함께 받아오기
                var adminno = response.adminno;
            }
        }
    });
    
        // 로그아웃 버튼 클릭 시
        $(document).on('click', '#logout_btn', function(e) {
            e.preventDefault(); // 기본 동작 중단

            $.ajax({
                type: "POST",
                url: "logout", // 로그아웃 요청을 보낼 URL
                success: function(response) {
                	alert('로그아웃 했습니다.');
                    window.location.reload(true);
                }
            });
        });
    
});