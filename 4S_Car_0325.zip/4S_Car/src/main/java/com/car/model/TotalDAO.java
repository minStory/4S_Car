package com.car.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class TotalDAO {
	
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sql = "";

	// TotalDAO 객체를 싱글톤 방식으로 만든다.

	// 1. TotalDAO 객체를 정적(static) 멤버로 선언 해 준다.
	private static TotalDAO instance = null;

	// 2. 기본 생성자를 private 로 선언한다.
	private TotalDAO() {}

	// 3. 기본 생성자 대신 instance 를 return 해 주는 getInstance() 매서드 선언.
	public static TotalDAO getInstance() {

		if (instance == null) {
			instance = new TotalDAO();
		}

		return instance;
	} // getInstance() end.

	
	// JDBC 방식이 아닌 DBCP 방식으로 DB와 연동 작업 진행.
	public void openConn() {

		try {
			
			// 1. JNDI 서버 객체 생성.
			// 자바의 네이밍 서비스(JNDI)에서 이름과 실제 객체를 연결 해 주는 개념이 Context 객체이며
			// , InitialContext 객체는 네이밍 서비스를 이용하기 위한 시작점이 된다.
			Context initCtx = new InitialContext();
			
			// 2. Context 객체를 얻어와야 함.
			// "java:comp/env" 라는 이름의 인수로 Context 객체를 얻어옴.
			// "java:comp/env" 는 현재 웹 애플리케이션에서 네이밍 서비스를 이용시 루트 디렉토리라고 생각하면 됨.
			// 즉, 현재 웹 애플리케이션이 사용 할 수 있는 모든 자원은 "java:comp/env" 아래에 위치를 하게 됨.
			Context ctx = (Context)initCtx.lookup("java:comp/env");
			
			// 3. lookup() 매서드를 이용하여 매칭되는 커넥션을 찾아옴.
			// "java:comp/env" 아래에 위치한 "jdbc/mysql" 자원을 얻어옴
			// 이 자원이 바로 데이터 소스(커넥션 풀)임.
			// 여기서 "jdbc/mysql" 은 context.xml 파일에 추가했던
			// <Resource> 태그 안에 있던 name 속성의 값임.
			DataSource ds = (DataSource)ctx.lookup("jdbc/mysql");
			
			// 4. DataSource 객체를 이용하여 커넥션을 하나 가져오면 됨.
			con = ds.getConnection();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	} // openConn() end.

	
	// DB에 연결된 자원을 종료하는 매서드.
	public void closeConn(ResultSet rs, PreparedStatement pstmt, Connection con) {

		try {

			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();
			if (con != null) con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	} // closeConn() end.

	public void closeConn(PreparedStatement pstmt, Connection con) {

		try {

			if (pstmt != null) pstmt.close();
			if (con != null) con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	} // closeConn() end.
	
	
	
	// 회원가입 페이지에서 입력받은 회원의 정보를 user Table에 insert 하는 매서드. 
	public int insertUser(UserDTO dto) {
		
		int result = 0, cnt = 0;

		try {

			openConn();
			
			sql = "select count(user_no) from user where user_no like ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, dto.getUser_no()+"%");
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				cnt = rs.getInt(1)+1;
			}
			
			sql = "insert into user values(?,?,?,?,?,?, default, default)";
			
			pstmt = con.prepareStatement(sql);
			
			if(cnt < 10) {
				pstmt.setString(1, dto.getUser_no()+"00"+cnt);
			} else if(cnt < 100) {
				pstmt.setString(1, dto.getUser_no()+"0"+cnt);
			} else {
				pstmt.setString(1, dto.getUser_no()+cnt);
			}
			pstmt.setString(2, dto.getUser_id());
			pstmt.setString(3, dto.getUser_pwd());
			pstmt.setString(4, dto.getUser_name());
			pstmt.setString(5, dto.getUser_phone());
			pstmt.setString(6, dto.getUser_email());
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		
		return result;
	} // insertUser(dto) end.
	
	
	
	// 사용자가 입력한 id와 pwd 가 유효한 값인지 check 하는 매서드.
	public int checkUserLogin(UserDTO dto) {
		
		int result = 0;
		
		try {

			openConn();
			
			sql = "select * from user where user_id = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, dto.getUser_id());
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {		// 입력받은 아이디와 일치한 아이디가 DB에 존재할 경우
				if(dto.getUser_pwd().equals(rs.getString("user_pwd"))) {	// 아이디가 존재하고, 입력받은 pwd가 일치 할 경우
					result = 1;
				}else {		// 일치하는 아이디가 DB에 존재하지만 입력한 비밀번호가 틀린경우
					result = -1;
				}
			} else {	// 입력받은 아이디가 DB에 존재하지 않을 경우.
				result = 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		
		return result;
	}	// checkUserLogin(dto) end.
	
	
	
	// 로그인 페이지에서 유효성 검사를 통과 후 관련 회원 정보를 모두 불러오는 매서드.
	public UserDTO userContent(UserDTO dto) {
		
		UserDTO cont = new UserDTO();
		
		try {

			openConn();
			
			sql = "select * from user where user_id = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, dto.getUser_id());
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				cont.setUser_no(rs.getString("user_no"));
				cont.setUser_id(rs.getString("user_id"));
				cont.setUser_pwd(rs.getString("user_pwd"));
				cont.setUser_name(rs.getString("user_name"));
				cont.setUser_phone(rs.getString("user_phone"));
				cont.setUser_email(rs.getString("user_email"));
				cont.setUser_mileage(rs.getInt("user_mileage"));
				cont.setUser_grade(rs.getString("user_grade"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		
		return cont;
	}	// userContent(dto) end.
	
	
	// 회원가입 폼에서 id 중복체크 하는 매서드.
	public int checkUserId(String user_id) {
		
		int result = 0;
		
		try {

			openConn();
			
			sql = "select * from user where user_id = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, user_id);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				result = -1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		
		return result;
	}	// checkUserId(userId) end.
	
	
	
	//	관리자 로그인 유효성 검사 매서드.
	public int checkAdminLogin(AdminDTO dto) {
		
		int result = 0;
		
		try {

			openConn();
			
			sql = "select * from admin where admin_id = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, dto.getAdmin_id());
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {		// 입력받은 아이디와 일치한 아이디가 DB에 존재할 경우
				if(dto.getAdmin_pwd().equals(rs.getString("admin_pwd"))) {	// 아이디가 존재하고, 입력받은 pwd가 일치 할 경우
					result = 1;
				}else {		// 일치하는 아이디가 DB에 존재하지만 입력한 비밀번호가 틀린경우
					result = -1;
				}
			} else {	// 입력받은 아이디가 DB에 존재하지 않을 경우.
				result = 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		
		return result;
	}	// checkAdminLogin(dto) end.
	
	
	// 관리자 로그인 페이지에서 유효성 검사를 통과 후 관련 관리자 정보를 모두 불러오는 매서드.
	public AdminDTO adminContent(AdminDTO dto) {
		
		AdminDTO cont = new AdminDTO();
		
		try {

			openConn();
			
			sql = "select * from admin where admin_id = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, dto.getAdmin_id());
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				cont.setAdmin_no(rs.getString("admin_no"));
				cont.setAdmin_id(rs.getString("admin_id"));
				cont.setAdmin_pwd(rs.getString("admin_pwd"));
				cont.setAdmin_name(rs.getString("admin_name"));
				cont.setAdmin_job(rs.getString("admin_job"));
				cont.setAdmin_phone(rs.getString("admin_phone"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		
		return cont;
	}	// adminContent(dto) end.
	
	
	
	
	// 판매 요청 게시판에 글 업로드하는 메서드
	   public int insertReqRegcar(ReqSellBoardDTO dto) {
	         
	         int result = 0, count = 0;
	         
	         String temp_user_no = null;
	         
	         try {
	            openConn();
	            
	            // 로그인 세션 미구현으로 DB에 있는 회원번호 임시로 가져온 것
	            sql = "select user_no from user";
	            
	            pstmt = con.prepareStatement(sql);
	            
	            rs = pstmt.executeQuery();
	            
	            if(rs.next()) {
	               temp_user_no = rs.getString(1);
	            }
	            System.out.println("요청자 회원번호 >>> " + temp_user_no);
	            rs.close();
	            ////////////////////////////////////////////////////

	            // 글번호 카운트
	            sql = "select max(req_sell_board_no) from req_sell_board";
	            
	            pstmt = con.prepareStatement(sql);
	            
	            rs = pstmt.executeQuery();
	            
	            if(rs.next()) {
	               count = rs.getInt(1);
	            }
	            
	            // DB에 데이터 저장
	            sql = "insert into req_sell_board values(?, ?, ?, ?, ?, ?, default, null, ?)";
	            
	            pstmt = con.prepareStatement(sql);
	            
	            pstmt.setInt(1, count + 1);
	            pstmt.setString(2, temp_user_no);
	            pstmt.setString(3, dto.getReq_sell_board_car_std_no());
	            pstmt.setString(4, dto.getReq_sell_board_car_no());
	            pstmt.setInt(5, dto.getReq_sell_board_car_distance());
	            pstmt.setString(6, dto.getReq_sell_board_car_detail());
	            pstmt.setString(7, dto.getReq_sell_board_car_file());
	            
	            result = pstmt.executeUpdate();
	            
	         }catch(Exception e) {
	            e.printStackTrace();
	         }finally {
	            closeConn(rs, pstmt, con);
	         }
	         
	         return result;
	      }
	      
	      // DB에 정보 저장 후 등록 요청 게시판 글번호 가져오는 메서드
	      public int getReqSellBoardNo() {
	         
	         int result = 0;
	         
	         try {
	            openConn();
	            
	            sql = "select max(req_sell_board_no) from req_sell_board";
	            
	            pstmt = con.prepareStatement(sql);
	            
	            rs = pstmt.executeQuery();
	            
	            if(rs.next()) {
	               result = rs.getInt(1);
	            }
	            
	         }catch(Exception e) {
	            e.printStackTrace();
	         }finally {
	            closeConn(rs, pstmt, con);
	         }
	         
	         return result;
	      }
	      
	      // DB에 정보 저장 후 등록 요청 게시판 요청일자 가져오는 메서드
	      public String getReqSellBoardDate() {
	         
	         String result = null ;
	         
	         try {
	            
	            openConn();
	            
	            sql = "select max(req_sell_board_date) from req_sell_board";
	            
	            pstmt = con.prepareStatement(sql);
	            
	            rs = pstmt.executeQuery();
	            
	            if(rs.next()) {
	               result = rs.getString(1);
	            }
	         }catch(Exception e) {
	            e.printStackTrace();
	         }finally {
	            closeConn(rs, pstmt, con);
	         }
	         
	         return result;
	      }
	
	
	
	
}	// class end.
