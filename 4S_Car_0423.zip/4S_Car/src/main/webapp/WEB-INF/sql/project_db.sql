-- 회사 정보 테이블
create table company(
    company_business_no varchar(50) primary key,            -- 사업자번호(123-45-67890)
    company_name varchar(50) not null,                     -- 회사명(4Scar)
    company_ceo_name varchar(50) not null,                  -- 대표이사
    company_addr varchar(50),                           -- 주소(충청남도 천안시 서북구 불당22대로 92 7층)
    company_phone varchar(50),                           -- 전화번호(1588-5530)
    company_found_date date,                           -- 설립일(20220501)
    company_account varchar(50) unique not null               -- 계좌번호(농협은행 352-1588-5530-99)
);

-- 관리자 정보 테이블
create table admin(
   admin_no varchar(50) primary key,                     -- 관리자번호 ex)A001
    admin_id varchar(50) unique key not null,              -- ID(admin01, admin02, admin03, admin04)
    admin_pwd varchar(50) not null,                        -- 비밀번호(1234)
    admin_name varchar(50) not null,                     -- 성명
    admin_job varchar(50) not null,                        -- 직책(ceo, site_manager, dealer)
    admin_phone varchar(50) not null                     -- 전화번호
);

-- 회원 정보 테이블
create table user(
   user_no varchar(50) primary key,                     -- 회원번호 ex)U20240318001
    user_id varchar(50) unique key not null,                        -- ID
    user_pwd varchar(50) not null,                        -- 비밀번호
    user_name varchar(50) not null,                        -- 성명
    user_phone varchar(50) not null,                     -- 전화번호
    user_email varchar(50) not null,                     -- 이메일
    user_mileage int default 0,                           -- 마일리지
    user_grade varchar(50) default "bronze",                  -- 회원등급
    user_regdate datetime default now()               -- 가입일
);

-- 차량 스펙 테이블
create table car(
    car_manufact_company varchar(50) not null,               -- 제조사
    car_manufact_year int not null,                        -- 연식
    car_manufact_month int not null,                        -- 월
    car_type varchar(50) not null,                        -- 종류
    car_fuel varchar(50) not null,                        -- 연료
    car_color varchar(50) not null,                        -- 색상
    car_transmission varchar(50) not null,               -- 변속기
    car_model varchar(50) not null                     -- 차량모델
);

-- 차량 판매 요청 게시판(user -> admin)                                                                                                                                                                                                                                                                                                                                                
create table req_sell_board(
    req_sell_board_no int primary key,                     -- 글번호
    req_sell_board_user_no varchar(50) not null,            -- 요청자 회원번호
    req_sell_board_car_std_no varchar(200) not null,            -- 요청차량 구분번호(차량 스펙 조인)
    req_sell_board_car_no varchar(50) unique not null,         -- 차량번호
    req_sell_board_car_distance int not null,               -- 주행거리
    req_sell_board_car_price int not null,                  -- 가격
    req_sell_board_car_detail varchar(2000) not null,         -- 차량 상세 정보(딜러에게 정보 제공)
    req_sell_board_date datetime not null default now(),      -- 요청일자
    req_sell_board_update datetime,                        -- 수정일자
    req_sell_board_car_file varchar(2000),                     -- 업로드 파일 저장 경로
    req_sell_board_status boolean not null default false,   -- 요청 승인 상태    
    
    foreign key (req_sell_board_user_no) references user (user_no) on update cascade
);

-- 차량 판매 게시판(admin)
create table sell_board(
    sell_board_no int primary key,                        -- 글번호
    sell_board_admin_no varchar(50) not null,               -- 관리자번호(딜러 정보 조인)
    sell_board_seller_no varchar(50) default null,          -- 판매자 회원번호(구매이력 조인)
    sell_board_car_std_no varchar(200) not null,               -- 등록차량 구분번호(차량 스펙 조인)
    sell_board_car_no varchar(50) not null,                  -- 차량번호(회원 요청 사항 조인)
    sell_board_car_distance int not null,               -- 차량 주행거리
    sell_board_car_price int not null,                  -- 가격
    sell_board_car_detail varchar(2000) not null,            -- 차량 상세 정보(홍보 내용)
    sell_board_date datetime not null default now(),         -- 등록일자
    sell_board_update datetime,                           -- 수정일자
    sell_board_car_file varchar(2000),                        -- 업로드 파일 저장 경로
    sell_board_status boolean not null default false,      -- 판매 상태
    
    foreign key (sell_board_admin_no) references admin (admin_no) on update cascade,
    foreign key (sell_board_seller_no) references user (user_no) on update cascade,
    foreign key (sell_board_car_no) references req_sell_board (req_sell_board_car_no) on update cascade on delete cascade
);

-- 차량 거래 이력 테이블
create table transaction(
   transaction_no int primary key,                          -- 거래번호
   transaction_seller_no varchar(50) not null,              -- 판매자 번호
   transaction_buyer_no varchar(50) not null,               -- 구매자 번호
   transaction_dealer_no varchar(50) not null,              -- 딜러 번호
   transaction_car_std_no varchar(200) not null,            -- 거래 차량 구분번호
   transaction_car_no varchar(50) not null,                 -- 거래 차량번호
   transaction_car_distance int not null,                   -- 거래 차량 주행거리
   transaction_car_price int not null,                      -- 가격
   transaction_date datetime not null default now(),        -- 거래일자
   transaction_sell_review_status boolean default false,	-- 판매자 후기글 등록 상태
   transaction_buy_review_status boolean default false,		-- 구매자 후기글 등록 상태
   
   foreign key (transaction_seller_no) references user (user_no) on update cascade,
   foreign key (transaction_buyer_no) references user (user_no) on update cascade,
   foreign key (transaction_dealer_no) references admin (admin_no) on update cascade
);

create table mileage(
   mileage_user_no varchar(50) not null,            -- 적립 회원번호
   mileage_date datetime default now(),            -- 적립 일시
    mileage_cont varchar(50) not null,               -- 적립 내용
    mileage_type varchar(50) not null,               -- 적립(+), 차감(-) 구분
    mileage_amount int not null,                  -- 적립 마일리지
    mileage_status int not null,                  -- 현재 마일리지
    mileage_grade varchar(50) not null               -- 현재 등급
);

-- 찜 목록 테이블
create table favorite(
    favorite_no int primary key,                        -- 찜목록 번호
    favorite_user_no varchar(50) not null,                  -- 찜한 회원번호
    favorite_sell_board_no int not null,                  -- 찜한 차량 판매 글번호
    
    foreign key (favorite_user_no) references user (user_no) on update cascade,
    foreign key (favorite_sell_board_no) references sell_board (sell_board_no) on delete cascade on update cascade
);

-- 결제 테이블
create table payment(
    payment_no varchar(50) primary key,                     -- 결제번호 ex)P20230318001
    payment_buyer_no varchar(50) not null,						-- 구매자 정보
    payment_method varchar(50) not null,                  -- 결제방식(현금, 카드)
    payment_card_company varchar(50),                     -- 카드사(카드결제 선택 시 not null)
    payment_card_no varchar(50),                        -- 카드번호(카드결제 선택 시 not null)
    payment_card_div_month int,                           -- 할부개월수(0~12)(카드결제 선택 시 not null)
    payment_card_pwd varchar(50),                        -- 카드 비밀번호(카드결제 선택 시 not null)
    payment_amount int not null,			                   -- 결제금액
    payment_sell_board_no int not null							-- 판매 테이블 넘버
);

-- 판매 후기 게시판 테이블
create table sell_review_board(
    sell_review_board_no int primary key,                        -- 글번호
    sell_review_board_writer_id varchar(50) not null,            -- 작성자
    sell_review_board_title varchar(50) not null,                -- 제목
    sell_review_board_cont varchar(50) not null,                 -- 내용
    sell_review_board_date datetime not null default now(),      -- 등록일시
    sell_review_board_update datetime,                           -- 수정일시
    sell_review_board_hit int default 0,                         -- 조회수
    sell_review_board_file varchar(2000),                   	 -- 파일 업로드 경로
    sell_review_transaction_no int,                        		 -- 거래내역 테이블 기본키
    
    foreign key (sell_review_transaction_no) references transaction (transaction_no) on update cascade
);

-- 자유 게시판 테이블
create table community_board(
    community_board_no int primary key,                     -- 글번호
    community_board_writer_id varchar(50) not null,            -- 작성자
    community_board_title varchar(50) not null,               -- 제목
    community_board_cont varchar(2000) not null,               -- 내용
    community_board_date datetime not null default now(),      -- 등록일시
    community_board_update datetime,                     -- 수정일시
    community_board_hit int                              -- 조회수
);

-- 구매 후기 게시판 테이블
create table buy_review_board(
    buy_review_board_no int primary key,                        -- 글번호
    buy_review_board_writer_id varchar(50) not null,            -- 작성자
    buy_review_board_title varchar(50) not null,                -- 제목
    buy_review_board_cont varchar(50) not null,                 -- 내용
    buy_review_board_date datetime not null default now(),      -- 등록일시
    buy_review_board_update datetime,                           -- 수정일시
    buy_review_board_hit int default 0,                         -- 조회수
    buy_review_board_file varchar(2000),                        -- 파일 업로드 경로
    buy_review_transaction_no int,                              -- 거래내역 테이블 기본키
    
    foreign key (buy_review_transaction_no) references transaction (transaction_no) on update cascade
);

create table qna_board(
    qna_board_no int primary key,                  -- 글번호
    qna_board_type varchar(50) not null,            -- 문의 유형
    qna_board_writer_id varchar(50) not null,         -- 작성자
    qna_board_title varchar(50) not null,            -- 제목
    qna_board_cont varchar(2000) not null,            -- 내용
    qna_board_date datetime not null default now(),      -- 게시일자
    qna_board_update datetime,                     -- 수정일자
    qna_board_file varchar(2000),                  -- 업로드 파일
    qna_board_status boolean not null default false      -- 문의 상태
);

create table notice_board(
   notice_board_no int primary key,                  -- 글번호
    notice_board_writer_id varchar(50) not null,         -- 작성자
    notice_board_title varchar(50) not null,            -- 제목
    notice_board_cont varchar(2000) not null,               -- 내용
    notice_board_date datetime not null default now(),      -- 게시일자
    notice_board_update datetime,                     -- 수정일자
    notice_board_hit int default 0,                     -- 조회수
    notice_board_file varchar(2000)                     -- 업로드 파일
);

create table event_board(
   event_board_no int primary key,                     -- 글번호
    event_board_writer_id varchar(50) not null,            -- 작성자
    event_board_title varchar(50) not null,               -- 제목
    event_board_cont varchar(2000) not null,               -- 내용
    event_board_date datetime not null default now(),      -- 게시일자
    event_board_update datetime,                     -- 수정일자
    event_board_hit int default 0,                     -- 조회수
    event_board_file varchar(2000)                     -- 업로드 파일
);

create table log(
   log_date datetime not null default now(),
    log_user_no varchar(50) not null,
    log_user_id varchar(50) not null,
    log_type varchar(50) not null
);

-- admin insert
insert into admin values("A001", "admin01", "1234", "박성민", "ceo", "010-0000-0000");
insert into admin values("A002", "admin02", "1234", "길호성", "site_manager", "010-0000-0000");
insert into admin values("A003", "admin03", "1234", "이솔", "dealer", "010-0000-0000");
insert into admin values("A004", "admin04", "1234", "구연서", "dealer", "010-0000-0000");

-- company info insert
insert into company values("123-45-67890", "(주)4Scar", "박성민", "충청남도 천안시 서북구 불당22대로 92 7층", "1588-5530", "20220501", "농협은행 352-1588-5530-99");

-- notice insert
insert into notice_board values(1, "A002", "안녕하세요 4Scar입니다.", "공지사항", default, null, default, null);
insert into notice_board values(2, "A002", "사이트 점검 일시 안내.", "공지사항", default, null, default, null);
insert into notice_board values(3, "A002", "결제 시스템 점검 안내.", "공지사항", default, null, default, null);
insert into notice_board values(4, "A002", "최근 이슈 관련 안내.", "공지사항", default, null, default, null);
insert into notice_board values(5, "A002", "금주 안내사항.", "공지사항", default, null, default, null);
insert into notice_board values(6, "A002", "금주 안내사항.ㄱ", "공지사항", default, null, default, null);
insert into notice_board values(7, "A002", "금주 안내사항.ㄴ", "공지사항", default, null, default, null);
insert into notice_board values(8, "A002", "금주 안내사항.ㄷ", "공지사항", default, null, default, null);
insert into notice_board values(9, "A002", "금주 안내사항.ㄹ", "공지사항", default, null, default, null);
insert into notice_board values(10, "A002", "금주 안내사항.ㅁ", "공지사항", default, null, default, null);
insert into notice_board values(11, "A002", "금주 안내사항.ㅂ", "공지사항", default, null, default, null);
insert into notice_board values(12, "A002", "금주 안내사항.ㅅ", "공지사항", default, null, default, null);
insert into notice_board values(13, "A002", "금주 안내사항.ㅇ", "공지사항", default, null, default, null);
insert into notice_board values(14, "A002", "금주 안내사항.ㅈ", "공지사항", default, null, default, null);
insert into notice_board values(15, "A002", "금주 안내사항.ㅊ", "공지사항", default, null, default, null);
insert into notice_board values(16, "A002", "금주 안내사항.ㅌ", "공지사항", default, null, default, null);
insert into notice_board values(17, "A002", "금주 안내사항.ㅍ", "공지사항", default, null, default, null);
insert into notice_board values(18, "A002", "금주 안내사항.ㅎ", "공지사항", default, null, default, null);
insert into notice_board values(19, "A002", "금주 안내사항.1", "공지사항", default, null, default, null);
insert into notice_board values(20, "A002", "금주 안내사항.2", "공지사항", default, null, default, null);
insert into notice_board values(21, "A002", "금주 안내사항.3", "공지사항", default, null, default, null);
insert into notice_board values(22, "A002", "금주 안내사항.4", "공지사항", default, null, default, null);
insert into notice_board values(23, "A002", "금주 안내사항.5", "공지사항", default, null, default, null);
insert into notice_board values(24, "A002", "금주 안내사항.6", "공지사항", default, null, default, null);
insert into notice_board values(25, "A002", "금주 안내사항.7", "공지사항", default, null, default, null);
insert into notice_board values(26, "A002", "금주 안내사항.8", "공지사항", default, null, default, null);
insert into notice_board values(27, "A002", "금주 안내사항.9", "공지사항", default, null, default, null);
insert into notice_board values(28, "A002", "금주 안내사항.10", "공지사항", default, null, default, null);
insert into notice_board values(29, "A002", "금주 안내사항.11", "공지사항", default, null, default, null);
insert into notice_board values(30, "A002", "금주 안내사항.12", "공지사항", default, null, default, null);
insert into notice_board values(31, "A002", "금주 안내사항.13", "공지사항", default, null, default, null);
insert into notice_board values(32, "A002", "금주 안내사항.14", "공지사항", default, null, default, null);
insert into notice_board values(33, "A002", "금주 안내사항.15", "공지사항", default, null, default, null);
insert into notice_board values(34, "A002", "금주 안내사항.16", "공지사항", default, null, default, null);
insert into notice_board values(35, "A002", "금주 안내사항.17", "공지사항", default, null, default, null);
insert into notice_board values(36, "A002", "금주 안내사항.18", "공지사항", default, null, default, null);
insert into notice_board values(37, "A002", "금주 안내사항.19", "공지사항", default, null, default, null);
insert into notice_board values(38, "A002", "금주 안내사항.20", "공지사항", default, null, default, null);
insert into notice_board values(39, "A002", "금주 안내사항.21", "공지사항", default, null, default, null);
insert into notice_board values(40, "A002", "금주 안내사항.22", "공지사항", default, null, default, null);
insert into notice_board values(41, "A002", "금주 안내사항.23", "공지사항", default, null, default, null);
insert into notice_board values(42, "A002", "금주 안내사항.24", "공지사항", default, null, default, null);
insert into notice_board values(43, "A002", "금주 안내사항.25", "공지사항", default, null, default, null);

-- event insert
insert into event_board values(1, "A002", "이벤트 리스트1.", "공지1사항", default, null, default, null);
insert into event_board values(2, "A002", "이벤트 리스트2.", "공지2사항", default, null, default, null);
insert into event_board values(3, "A002", "이벤트 리스트3.", "공지3사항", default, null, default, null);
insert into event_board values(4, "A002", "이벤트 리스트4.", "공지4사항", default, null, default, null);
insert into event_board values(5, "A002", "이벤트 리스트5.", "공지5사항", default, null, default, null);
insert into event_board values(6, "A002", "이벤트 리스트6.", "공지6사항", default, null, default, null);
insert into event_board values(7, "A002", "이벤트 리스트7.", "공지7사항", default, null, default, null);
insert into event_board values(8, "A002", "이벤트 리스트8.", "공지8사항", default, null, default, null);
insert into event_board values(9, "A002", "이벤트 리스트9.", "공지9사항", default, null, default, null);
insert into event_board values(10, "A002", "이벤트 리스트10.", "공지ㄱ사항", default, null, default, null);
insert into event_board values(11, "A002", "이벤트 리스트11.", "공지ㄴ사항", default, null, default, null);
insert into event_board values(12, "A002", "이벤트 리스트12.", "공지ㄷ사항", default, null, default, null);
insert into event_board values(13, "A002", "이벤트 리스트13.", "공지ㄹ사항", default, null, default, null);
insert into event_board values(14, "A002", "이벤트 리스트14.", "공지ㅁ사항", default, null, default, null);
insert into event_board values(15, "A002", "이벤트 리스트15.", "공지ㅂ사항", default, null, default, null);
insert into event_board values(16, "A002", "이벤트 리스트ㄱ.", "공지ㅅ사항", default, null, default, null);
insert into event_board values(17, "A002", "이벤트 리스트ㄴ.", "공지ㅇㅇ사항", default, null, default, null);
insert into event_board values(18, "A002", "이벤트 리스트ㄷ.", "공지ㅋㅌ사항", default, null, default, null);
insert into event_board values(19, "A002", "이벤트 리스트ㄱ.", "공지ㅈㅈ사항", default, null, default, null);
insert into event_board values(20, "A002", "이벤트 리스트ㅁ.", "공지ㅂㄷ사항", default, null, default, null);
insert into event_board values(21, "A002", "이벤트 리스트ㅂ.", "공지ㅌ사항", default, null, default, null);
insert into event_board values(22, "A002", "이벤트 리스트ㅅ.", "공지ㅁㅇㅈ사항", default, null, default, null);
insert into event_board values(23, "A002", "이벤트 리스트ㅇ.", "공지asd사항", default, null, default, null);
insert into event_board values(24, "A002", "이벤트 리스트ㅈ.", "공지qwe사항", default, null, default, null);
insert into event_board values(25, "A002", "이벤트 리스트ㅊ.", "공지zxc사항", default, null, default, null);

-- user insert
insert into user values ("U20240418001", "psm9024", 1234, "박성민", "010-1234-5678", "이@메.일", 10000, default, default);
insert into user values ("U20240418002", "rlfghtjd", 1234, "길호성", "010-1234-5678", "이@메.일", 10000, default, default);
insert into user values ("U20240418003", "qnq11", 1234, "구연서", "010-1234-5678", "이@메.일", 10000, default, default);
insert into user values ("U20240418004", "lmo05200", 1234, "이솔", "010-1234-5678", "이@메.일", 10000, default, default);
insert into user values ("U20240418005", "qwer1", 1234, "권오성", "010-0000-1234", "이@메.일", 10000, default, default);
insert into user values ("U20240418006", "asdf1", 1234, "권용진", "010-0000-1234", "이@메.일", 10000, default, default);
insert into user values ("U20240418007", "zxcv1", 1234, "동화", "010-0000-1234", "이@메.일", 10000, default, default);
insert into user values ("U20240418008", "qwer2", 1234, "염종원", "010-0000-1234", "이@메.일", 10000, default, default);
insert into user values ("U20240418009", "asdf3", 1234, "이동훈", "010-0000-1234", "이@메.일", 10000, default, default);
insert into user values ("U20240418010", "asdf2", 1234, "이재성", "010-0000-1234", "이@메.일", 10000, default, default);
insert into user values ("U20240418011", "zxcv2", 1234, "이찬우", "010-0000-1234", "이@메.일", 10000, default, default);
insert into user values ("U20240418012", "qwer3", 1234, "천재희", "010-0000-1234", "이@메.일", 10000, default, default);
insert into user values ("U20240418013", "qwer4", 1234, "최유경", "010-0000-1234", "이@메.일", 10000, default, default);


-- req_sell_board insert
insert into req_sell_board values (1, "U20240418001", "현대_대형_2022_3_LPG_자동_검정색_그랜저", "11가1111", 10000, 34000000, "req_sell_board insert1", "2024-04-18", null, "../images/logos-brand-현대.png", default);
insert into req_sell_board values (2, "U20240418001", "제네시스_대형_2021_5_가솔린_자동_회색_G90", "22나2222", 20000, 30000000, "req_sell_board insert2", "2024-04-18", null, "../images/logos-brand-제네시스.png", default);
insert into req_sell_board values (3, "U20240418001", "기아_SUV_2010_12_디젤_자동_검정색_쏘렌토", "33다3333", 30000, 35000000, "req_sell_board insert3", "2024-04-18", null, "../images/logos-brand-기아.png", default);
insert into req_sell_board values (4, "U20240418001", "쉐보레_중형_2013_11_가솔린_자동_은색_임팔라", "44라4444", 40000, 20000000, "req_sell_board insert4", "2024-04-18", null, "../images/logos-brand-쉐보레.png", default);
insert into req_sell_board values (5, "U20240418001", "르노코리아_중형_2020_7_가솔린_자동_흰색_SM5", "55마5555", 50000, 15000000, "req_sell_board insert5", "2024-04-18", null, "../images/logos-brand-르노코리아.png", default);
insert into req_sell_board values (6, "U20240418001", "대우_화물_2018_3_디젤_자동_검정색_다마스", "66바6666", 60000, 18000000, "req_sell_board insert6", "2024-04-18", null, "../images/logos-brand-대우.png", default);
insert into req_sell_board values (7, "U20240418001", "쌍용_SUV_2019_3_가솔린_자동_빨간색_티볼리", "77사7777", 70000, 28500000, "req_sell_board insert7", "2024-04-18", null, "../images/logos-brand-쌍용.png", default);
insert into req_sell_board values (8, "U20240418001", "벤츠_대형_2015_6_하이브리드_자동_파란색_S560", "88아8888", 80000, 160000000, "req_sell_board insert8", "2024-04-18", null, "../images/logos-brand-벤츠.png", default);
insert into req_sell_board values (9, "U20240418001", "BMW_대형_2022_1_가솔린_자동_은색_528I", "99자9999", 90000, 56000000, "req_sell_board insert9", "2024-04-18", null, "../images/logos-brand-bmw.png", default);
insert into req_sell_board values (10, "U20240418001", "아우디_대형_2023_4_디젤_자동_흰색_A8", "111차1111", 100000, 110000000, "req_sell_board insert10", "2024-04-18", null, "../images/logos-brand-아우디.png", default);
insert into req_sell_board values (11, "U20240418001", "폭스바겐_SUV_2009_9_디젤_자동_검정색_티구안", "222카2222", 110000, 44000000, "req_sell_board insert11", "2024-04-18", null, "../images/logos-brand-폭스바겐.png", default);
insert into req_sell_board values (12, "U20240418001", "미니_소형_2016_12_가솔린_수동_검정색_컨트리맨", "333타3333", 120000, 35000000, "req_sell_board insert12", "2024-04-18", null, "../images/logos-brand-미니.png", default);
insert into req_sell_board values (13, "U20240418001", "볼보_SUV_2018_10_디젤_자동_빨간색_XC90", "444파4444", 130000, 85000000, "req_sell_board insert13", "2024-04-18", null, "../images/logos-brand-볼보.png", default);
insert into req_sell_board values (14, "U20240418001", "폴스타_대형_2017_1_가솔린_자동_검정색_폴스타6", "555하5555", 140000, 75000000, "req_sell_board insert14", "2024-04-18", null, "../images/logos-brand-폴스타.png", default);
insert into req_sell_board values (15, "U20240418001", "포르쉐_SUV_2020_2_디젤_자동_검정색_카이엔", "666거6666", 150000, 105000000, "req_sell_board insert15", "2024-04-18", null, "../images/logos-brand-포르쉐.png", default);
insert into req_sell_board values (16, "U20240418001", "도요타_중형_2019_9_LPG_자동_회색_프리우스", "777너7777", 160000, 31000000, "req_sell_board insert16", "2024-04-18", null, "../images/logos-brand-도요타.png", default);
insert into req_sell_board values (17, "U20240418001", "벤츠_대형_2021_8_전기_자동_회색_E350", "888더8888", 170000, 56000000, "req_sell_board insert17", "2024-04-18", null, "../images/logos-brand-벤츠.png", default);
insert into req_sell_board values (18, "U20240418001", "BMW_스포츠_2017_2_가솔린_수동_은색_M4", "999러9999", 180000, 60000000, "req_sell_board insert18", "2024-04-18", null, "../images/logos-brand-bmw.png", default);
insert into req_sell_board values (19, "U20240418001", "아우디_중형_2019_5_전기_자동_흰색_A6", "123머1234", 190000, 70000000, "req_sell_board insert19", "2024-04-18", null, "../images/logos-brand-아우디.png", default);
insert into req_sell_board values (20, "U20240418001", "폭스바겐_중형_2018_9_가솔린_자동_검정색_아테온", "456버4567", 200000, 44000000, "req_sell_board insert20", "2024-04-18", null, "../images/logos-brand-폭스바겐.png", default);

-- sell_board insert
insert into sell_board values (1, "A001", "U20240418001", "현대_대형_2022_3_LPG_자동_검정색_그랜저", "11가1111", 10000, 34000000, "sell_board insert1", "2024-04-18", null, "../images/logos-brand-현대.png", default);
insert into sell_board values (2, "A001", "U20240418001", "제네시스_대형_2021_5_가솔린_자동_회색_G90", "22나2222", 20000, 30000000, "sell_board insert2", "2024-04-18", null, "../images/logos-brand-제네시스.png", default);
insert into sell_board values (3, "A001", "U20240418001", "기아_SUV_2010_12_디젤_자동_검정색_쏘렌토", "33다3333", 30000, 35000000, "sell_board insert3", "2024-04-18", null, "../images/logos-brand-기아.png", default);
insert into sell_board values (4, "A001", "U20240418001", "쉐보레_중형_2013_11_가솔린_자동_은색_임팔라", "44라4444", 40000, 20000000, "sell_board insert4", "2024-04-18", null, "../images/logos-brand-쉐보레.png", default);
insert into sell_board values (5, "A001", "U20240418001", "르노코리아_중형_2020_7_가솔린_자동_흰색_SM5", "55마5555", 50000, 15000000, "sell_board insert5", "2024-04-18", null, "../images/logos-brand-르노코리아.png", default);
insert into sell_board values (6, "A001", "U20240418001", "대우_화물_2018_3_디젤_자동_검정색_다마스", "66바6666", 60000, 18000000, "sell_board insert6", "2024-04-18", null, "../images/logos-brand-대우.png", default);
insert into sell_board values (7, "A001", "U20240418001", "쌍용_SUV_2019_3_가솔린_자동_빨간색_티볼리", "77사7777", 70000, 28500000, "sell_board insert7", "2024-04-18", null, "../images/logos-brand-쌍용.png", default);
insert into sell_board values (8, "A001", "U20240418001", "벤츠_대형_2015_6_하이브리드_자동_파란색_S560", "88아8888", 80000, 160000000, "sell_board insert8", "2024-04-18", null, "../images/logos-brand-벤츠.png", default);
insert into sell_board values (9, "A001", "U20240418001", "BMW_대형_2022_1_가솔린_자동_은색_528I", "99자9999", 90000, 56000000, "sell_board insert9", "2024-04-18", null, "../images/logos-brand-bmw.png", default);
insert into sell_board values (10, "A001", "U20240418001", "아우디_대형_2023_4_디젤_자동_흰색_A8", "111차1111", 100000, 110000000, "sell_board insert10", "2024-04-18", null, "../images/logos-brand-아우디.png", default);
insert into sell_board values (11, "A001", "U20240418001", "폭스바겐_SUV_2009_9_디젤_자동_검정색_티구안", "222카2222", 110000, 44000000, "sell_board insert11", "2024-04-18", null, "../images/logos-brand-폭스바겐.png", default);
insert into sell_board values (12, "A001", "U20240418001", "미니_소형_2016_12_가솔린_수동_검정색_컨트리맨", "333타3333", 120000, 35000000, "sell_board insert12", "2024-04-18", null, "../images/logos-brand-미니.png", default);
insert into sell_board values (13, "A001", "U20240418001", "볼보_SUV_2018_10_디젤_자동_빨간색_XC90", "444파4444", 130000, 85000000, "sell_board insert13", "2024-04-18", null, "../images/logos-brand-볼보.png", default);
insert into sell_board values (14, "A001", "U20240418001", "폴스타_대형_2017_1_가솔린_자동_검정색_폴스타6", "555하5555", 140000, 75000000, "sell_board insert14", "2024-04-18", null, "../images/logos-brand-폴스타.png", default);
insert into sell_board values (15, "A001", "U20240418001", "포르쉐_SUV_2020_2_디젤_자동_검정색_카이엔", "666거6666", 150000, 105000000, "sell_board insert15", "2024-04-18", null, "../images/logos-brand-포르쉐.png", default);
insert into sell_board values (16, "A001", "U20240418001", "도요타_중형_2019_9_LPG_자동_회색_프리우스", "777너7777", 160000, 31000000, "sell_board insert16", "2024-04-18", null, "../images/logos-brand-도요타.png", default);
insert into sell_board values (17, "A001", "U20240418001", "벤츠_대형_2021_8_전기_자동_회색_E350", "888더8888", 170000, 56000000, "sell_board insert17", "2024-04-18", null, "../images/logos-brand-벤츠.png", default);
insert into sell_board values (18, "A001", "U20240418001", "BMW_스포츠_2017_2_가솔린_수동_은색_M4", "999러9999", 180000, 60000000, "sell_board insert18", "2024-04-18", null, "../images/logos-brand-bmw.png", default);
insert into sell_board values (19, "A001", "U20240418001", "아우디_중형_2019_5_전기_자동_흰색_A6", "123머1234", 190000, 70000000, "sell_board insert19", "2024-04-18", null, "../images/logos-brand-아우디.png", default);
insert into sell_board values (20, "A001", "U20240418001", "폭스바겐_중형_2018_9_가솔린_자동_검정색_아테온", "456버4567", 200000, 44000000, "sell_board insert20", "2024-04-18", null, "../images/logos-brand-폭스바겐.png", default);

-- qna_board insert
insert into qna_board values(1, "서비스", "psm9024", "문의합니다.", "문의문의1234", default, null, null, 0);
insert into qna_board values(2, "내차팔기", "psm9024", "팔래요.", "문의문의1234", default, null, null, 1);
insert into qna_board values(3, "내차사기", "rlfghtjd", "문의합니다.", "문의문의1234", default, null, null, 0);
insert into qna_board values(4, "불편접수", "rlfghtjd", "불-편", "문의문의1234", default, null, null, 0);
insert into qna_board values(5, "오류신고", "psm9024", "문의합니다.", "문의문의1234", default, null, null, 0);
insert into qna_board values(6, "오류신고", "rlfghtjd", "오류발견", "문의문의1234", default, null, null, 1);
insert into qna_board values(7, "서비스", "qnq11", "서비스불만족", "문의문의1234", default, null, null, 0);
insert into qna_board values(8, "내차팔기", "qnq11", "배고프다.", "문의문의1234", default, null, null, 1);
insert into qna_board values(9, "내차사기", "qnq11", "고생.", "문의문의1234", default, null, null, 1);
insert into qna_board values(10, "내차사기", "qnq11", "질문해요.", "문의문의1234", default, null, null, 0);
insert into qna_board values(11, "불편접수", "lmo05200", "이건.", "문의문의1234", default, null, null, 0);
insert into qna_board values(12, "서비스", "lmo05200", "어떤가요.", "문의문의1234", default, null, null, 0);
insert into qna_board values(13, "내차사기", "lmo05200", "사고싶어요.", "문의문의1234", default, null, null, 1);
insert into qna_board values(14, "내차팔기", "lmo05200", "팔고싶어요.", "문의문의1234", default, null, null, 1);

-- transaction insert 예정

-- buy_review_board insert 예정

-- sell_review_board insert 예정

-- community_board insert 예정


SET SQL_SAFE_UPDATES = 0;

select * from sell_board;

commit;