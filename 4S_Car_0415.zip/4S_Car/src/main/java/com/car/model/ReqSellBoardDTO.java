package com.car.model;

public class ReqSellBoardDTO {

	private int req_sell_board_no;
	private String req_sell_board_user_no;
	private String req_sell_board_car_std_no;
	private String req_sell_board_car_no;
	private int req_sell_board_car_distance;
	private int req_sell_board_car_price;
	private String req_sell_board_car_detail;
	private String req_sell_board_date;
	private String req_sell_board_update;
	private String req_sell_board_car_file;
	private boolean req_sell_board_status;
	
	public int getReq_sell_board_no() {
		return req_sell_board_no;
	}
	public void setReq_sell_board_no(int req_sell_board_no) {
		this.req_sell_board_no = req_sell_board_no;
	}
	public String getReq_sell_board_user_no() {
		return req_sell_board_user_no;
	}
	public void setReq_sell_board_user_no(String req_sell_board_user_no) {
		this.req_sell_board_user_no = req_sell_board_user_no;
	}
	public String getReq_sell_board_car_std_no() {
		return req_sell_board_car_std_no;
	}
	public void setReq_sell_board_car_std_no(String req_sell_board_car_std_no) {
		this.req_sell_board_car_std_no = req_sell_board_car_std_no;
	}
	public String getReq_sell_board_car_no() {
		return req_sell_board_car_no;
	}
	public void setReq_sell_board_car_no(String req_sell_board_car_no) {
		this.req_sell_board_car_no = req_sell_board_car_no;
	}
	public int getReq_sell_board_car_distance() {
		return req_sell_board_car_distance;
	}
	public void setReq_sell_board_car_distance(int req_sell_board_car_distance) {
		this.req_sell_board_car_distance = req_sell_board_car_distance;
	}
	public String getReq_sell_board_car_detail() {
		return req_sell_board_car_detail;
	}
	public void setReq_sell_board_car_detail(String req_sell_board_car_detail) {
		this.req_sell_board_car_detail = req_sell_board_car_detail;
	}
	public String getReq_sell_board_date() {
		return req_sell_board_date;
	}
	public void setReq_sell_board_date(String req_sell_board_date) {
		this.req_sell_board_date = req_sell_board_date;
	}
	public String getReq_sell_board_update() {
		return req_sell_board_update;
	}
	public void setReq_sell_board_update(String req_sell_board_update) {
		this.req_sell_board_update = req_sell_board_update;
	}
	public String getReq_sell_board_car_file() {
		return req_sell_board_car_file;
	}
	public void setReq_sell_board_car_file(String req_sell_board_car_file) {
		this.req_sell_board_car_file = req_sell_board_car_file;
	}
	public int getReq_sell_board_car_price() {
		return req_sell_board_car_price;
	}
	public void setReq_sell_board_car_price(int req_sell_board_car_price) {
		this.req_sell_board_car_price = req_sell_board_car_price;
	}
	public boolean isReq_sell_board_status() {
		return req_sell_board_status;
	}
	public void setReq_sell_board_status(boolean req_sell_board_status) {
		this.req_sell_board_status = req_sell_board_status;
	}
	
	
	
	
	
	
}
