package com.car.action;

public class StaticArea {
	
	// 날짜 정보 month를 2자리로 맞추기 위한 메서드
	   public static String getMonth(int month) {
	      if(month < 10) {
	         return "0" + String.valueOf(month);
	      }else {
	         return String.valueOf(month);
	      }
	   }
	   
	   // 날짜 정보 day를 2자리로 맞추기 위한 메서드
	   public static String getDay(int day) {
	      if(day < 10) {
	         return "0" + String.valueOf(day);
	      }else {
	         return String.valueOf(day);
	      }
	   }
}
