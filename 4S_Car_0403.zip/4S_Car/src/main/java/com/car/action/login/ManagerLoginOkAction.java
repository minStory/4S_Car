package com.car.action.login;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.model.AdminDTO;
import com.car.model.TotalDAO;

public class ManagerLoginOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String admin_id = request.getParameter("admin_id").trim();
		String admin_pwd = request.getParameter("admin_pwd").trim();
		
		AdminDTO dto = new AdminDTO();
		
		dto.setAdmin_id(admin_id);
		dto.setAdmin_pwd(admin_pwd);
		
		TotalDAO dao = TotalDAO.getInstance();
		
		int check = dao.checkAdminLogin(dto);
		
		PrintWriter out = response.getWriter();
				
		if(check == 1) {
			
			HttpSession session = request.getSession();
			AdminDTO cont = dao.adminContent(dto);
			session.setAttribute("name", cont.getAdmin_name());
			session.setAttribute("no", cont.getAdmin_no());
			session.setAttribute("dto", cont);
			out.println("<script>");
			out.println("alert('로그인했습니다.')");
			out.println("</script>");
			response.sendRedirect(request.getContextPath() + "/main.jsp");
			
		} else if(check == -1) {
			out.println("<script>");
			out.println("alert('비밀번호가 일치하지 않습니다!')");
			out.println("history.back()");
			out.println("</script>");
		} else  {
			out.println("<script>");
			out.println("alert('일치하는 아이디를 찾을수 없습니다.')");
			out.println("history.back()");
			out.println("</script>");
		} 
		out.close();
		return null;
	}

}
