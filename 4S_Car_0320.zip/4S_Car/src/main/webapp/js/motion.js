
$(function(){

    var carSell = $(".car_sell");

    var carBuy = $(".car_sell");

    var myPage = $(".car_sell");

    var comunity = $(".car_sell");
    
    var gongji = $(".gongju");


    var menual_1 = $("lnb1");

    var menual_2 = $("lnb2");

    var menual_3 = $("lnb3");

    var menual_4 = $("lnb4");

    var menual_5 = $("lnb5");
   
 
   
        $(".scroll_top").click(function(){
            $("html").animate({ scrollTop: 0 });
        })
   








        
   });

