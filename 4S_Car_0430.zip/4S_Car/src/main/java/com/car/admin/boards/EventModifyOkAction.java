package com.car.admin.boards;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.action.StaticArea;
import com.car.model.AdminDTO;
import com.car.model.EventBoardDTO;
import com.car.model.TotalDAO;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class EventModifyOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		StaticArea.checkAdminDTO(request, response);

		HttpSession session = request.getSession();

		AdminDTO cont = (AdminDTO) session.getAttribute("dto");

		String saveFolder = "D:\\JSP\\4S_Car\\src\\main\\webapp\\upload_images";

		int fileSize = 10 * 1024 * 1024; // 10MB

		MultipartRequest multi = new MultipartRequest(request, // 일반적인 request 객체
				saveFolder, // 첨부파일이 저장될 경로
				fileSize, // 업로드할 첨부파일의 최대 크기
				"UTF-8", // 문자 인코딩 방식
				new DefaultFileRenamePolicy() // 첨부파일의 이름이 같은 경우 중복이 안되게 설정
		);

		int event_board_no = Integer.parseInt(multi.getParameter("event_board_no").trim());
		String title = multi.getParameter("title").trim();
		String content = multi.getParameter("content").trim();

		File event_file = multi.getFile("event_file");

		EventBoardDTO dto = new EventBoardDTO();

		dto.setEvent_board_no(event_board_no);
		dto.setEvent_board_title(title);
		dto.setEvent_board_cont(content);

		TotalDAO dao = TotalDAO.getInstance();

		int check = dao.updateEvent(dto);

		if (check > 0) {
			ActionForward forward = new ActionForward();

			forward.setPath("/WEB-INF/views/admin/boards/event_modify_ok.jsp");

			return forward;

		} else {
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('글 수정에 실패했습니다. 입력한 정보를 다시 확인하세요.')");
			out.println("history.back()");
			out.println("</script>");
			out.close();
		}

		return null;

	}

}
