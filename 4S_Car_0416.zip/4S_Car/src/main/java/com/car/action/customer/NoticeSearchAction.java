package com.car.action.customer;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.model.NoticeBoardDTO;
import com.car.model.TotalDAO;

public class NoticeSearchAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String notice_field = request.getParameter("field").trim();
		String notice_keyword = request.getParameter("notice_keyword").trim();
		
		TotalDAO dao = TotalDAO.getInstance();
		
		List<NoticeBoardDTO> list = dao.searchNoticeList(notice_field, notice_keyword);
		
		request.setAttribute("notice_list", list);
		
		ActionForward forward = new ActionForward();
		
		forward.setPath("/WEB-INF/views/public/customer/notice_list.jsp");
		
		return forward;
	}

}
