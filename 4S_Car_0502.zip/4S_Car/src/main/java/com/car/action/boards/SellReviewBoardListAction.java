package com.car.action.boards;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.model.SellReviewBoardDTO;
import com.car.model.TotalDAO;

public class SellReviewBoardListAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int sellReview_rowsize = 10;

		int sellReview_block = 3;

		int sellReview_count = 0;

		int sellReview_allPage = 0;

		int sellReview_page = 0;

		if (request.getParameter("sellReview_page") != null) {
			sellReview_page = Integer.parseInt(request.getParameter("sellReview_page").trim());

		} else {
			sellReview_page = 1;
		}

		int sellReview_startNo = (sellReview_page * sellReview_rowsize - 1);

		int sellReview_endNo = (sellReview_page * sellReview_rowsize);

		int sellReview_startBlock = (((sellReview_page - 1) / sellReview_block) * sellReview_block) + 1;

		int sellReview_endBlock = (((sellReview_page - 1) / sellReview_block) * sellReview_block) + sellReview_block;

		TotalDAO dao = TotalDAO.getInstance();

		sellReview_count = dao.countSellReviewBoardList();

		sellReview_allPage = (int) Math.ceil(sellReview_count / (double) sellReview_rowsize);

		if (sellReview_endBlock > sellReview_allPage) {
			sellReview_endBlock = sellReview_allPage;
		}

		boolean is_srSearch = false;

		List<SellReviewBoardDTO> list = dao.getSellReviewList(sellReview_page, sellReview_rowsize);

		request.setAttribute("sellReview_rowsize", sellReview_rowsize);
		request.setAttribute("sellReview_block", sellReview_block);
		request.setAttribute("sellReview_count", sellReview_count);
		request.setAttribute("sellReview_allPage", sellReview_allPage);
		request.setAttribute("sellReview_page", sellReview_page);
		request.setAttribute("sellReview_startNo", sellReview_startNo);
		request.setAttribute("sellReview_endNo", sellReview_endNo);
		request.setAttribute("sellReview_startBlock", sellReview_startBlock);
		request.setAttribute("sellReview_endBlock", sellReview_endBlock);
		request.setAttribute("list", list);
		request.setAttribute("is_srSearch", is_srSearch);

		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/public/boards/sell_review_board_list.jsp");

		return forward;
	}

}