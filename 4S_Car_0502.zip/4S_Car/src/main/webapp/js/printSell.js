$(document).ready(function() {
	$.ajax({
	        type: "GET",
	        url: "print_sell_list",
	        dataType: "json",
	        success: function(response) {
	            if(response.length === 0) {
	            	// 공지사항이 없는 경우
	            } else {
		            // 공지사항 리스트를 받아서 필요한 작업을 수행
		            printSellList(response);
	            }
	        },
	        error: function(xhr, status, error) {
	            // 오류 발생 시 처리
	            console.error("오류:", error);
	        }
	});
})
function printSellList(boards) {
	var boardsHtml = "";
	boardsHtml += "<ul>";
	$.each(boards, function(index, board) {
		boardsHtml += "<li>" + "<div class='fam-img'>" + "<a href='car_list_content?no=";
		boardsHtml += board.no + "'>"
		boardsHtml += "<img src='upload_images/"+ board.file + "'>" + "</a></div>";
		boardsHtml += "<div class='fam-product1'><p class='p'>" + board.std + "</p>";
		boardsHtml += "<p>가격 <span>" + board.price + "</span> 원</p>";
		boardsHtml += "</div></li>";
	});
	boardsHtml += "</ul>";
	$(".fam-product").html(boardsHtml);
}