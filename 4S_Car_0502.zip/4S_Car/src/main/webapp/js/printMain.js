function fetchNotice() {
    return new Promise(function(resolve, reject) {
        $.ajax({
            type: "GET",
            url: "print_notice",
            dataType: "json",
            success: function(response) {
                if (response.length === 0) {
                    reject("No notices found");
                } else {
                    resolve(response);
                }
            },
            error: function(xhr, status, error) {
                reject(error);
            }
        });
    });
}

function fetchSellList() {
    return new Promise(function(resolve, reject) {
        $.ajax({
            type: "GET",
            url: "print_sell_list",
            dataType: "json",
            success: function(response) {
                if (response.length === 0) {
                    reject("No sell list found");
                } else {
                    resolve(response);
                }
            },
            error: function(xhr, status, error) {
                reject(error);
            }
        });
    });
}

$(document).ready(function() {
    fetchNotice()
        .then(function(response) {
            printNotices(response);
        })
        .catch(function(error) {
            console.error("Notice Error:", error);
        });

    fetchSellList()
        .then(function(response) {
            printSellList(response);
        })
        .catch(function(error) {
            console.error("Sell List Error:", error);
        });
});

function printNotices(notices) {
    var noticesHtml = "";
    $.each(notices, function(index, notice) {
        if (index === 4) {
            noticesHtml += "<div><span>";
            noticesHtml += "<a href='main_notice_content?no=" + notice.no + "'>" + notice.title + "</a>";
            noticesHtml += "</span>" + "<span>" + notice.date.substring(0, 10) + "</span></div>";
        } else {
            noticesHtml += "<div><span>";
            noticesHtml += "<a href='main_notice_content?no=" + notice.no + "'>" + notice.title + "</a>";
            noticesHtml += "</span>" + "<span>" + notice.date.substring(0, 10) + "</span></div>" + "<hr>";
        }
    });
    $(".notice_mainpage_box2 .notice_display").html(noticesHtml);
    $('.notice_mainpage_box2 a').hover(function() {
        $(this).css("text-decoration", "underline");
    }, function() {
        $(this).css('text-decoration', 'none');
    });
}

function printSellList(boards) {
    var boardsHtml = "";
    boardsHtml += "<ul>";
    $.each(boards, function(index, board) {
        boardsHtml += "<li>" + "<div class='fam-img'><a href='car_list_content?no=";
        boardsHtml += board.no + "'><img src='upload_images/"+ board.file + "'></a></div>";
        boardsHtml += "<div class='fam-product1'><p class='p'>" + board.std + "</p>";
        boardsHtml += "<p>가격 <span>" + board.price + "</span> 원</p>";
        boardsHtml += "</div></li>";
    });
    boardsHtml += "</ul>";
    $(".fam-product").html(boardsHtml);
}