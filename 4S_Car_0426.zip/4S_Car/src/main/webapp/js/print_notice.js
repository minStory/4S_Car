$(document).ready(function() {
	$.ajax({
        type: "GET",
        url: "print_notice", // 공지사항을 가져오는 서블릿의 URL
        dataType: "json",
        success: function(response) {
            if(response.length === 0) {
            	// 공지사항이 없는 경우
            } else {
	            // 공지사항 리스트를 받아서 필요한 작업을 수행
	            printNotices(response);
            }
        },
        error: function(xhr, status, error) {
            // 오류 발생 시 처리
            console.error("오류:", error);
        }
    });
    
    function printNotices(notices) {
        var noticesHtml = "";
        $.each(notices, function(index, notice) {
        	if(index === 4){
        		noticesHtml += "<div><span>";
	            noticesHtml += "<a href='main_notice_content?no=" + notice.no + "'>" + notice.title + "</a>";
	            noticesHtml += "</span>" + "<span>" + notice.date.substring(0, 10) + "</span></div>";
        	} else {
	            noticesHtml += "<div><span>";
	            noticesHtml += "<a href='main_notice_content?no=" + notice.no + "'>" + notice.title + "</a>";
	            noticesHtml += "</span>" + "<span>" + notice.date.substring(0, 10) + "</span></div>" +"<hr>";
            }
        });
        $(".notice_mainpage_box2 .notice_display").html(noticesHtml);
        $('.notice_mainpage_box2 a').hover(function() {
            $(this).css("text-decoration", "underline");
        },function() {
            $(this).css('text-decoration', 'none');
        })
    }
})