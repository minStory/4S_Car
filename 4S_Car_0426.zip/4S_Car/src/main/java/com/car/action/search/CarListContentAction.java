package com.car.action.search;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.action.StaticArea;
import com.car.model.AdminDTO;
import com.car.model.CompanyDTO;
import com.car.model.SellBoardDTO;
import com.car.model.TotalDAO;

public class CarListContentAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int board_no = Integer.parseInt(request.getParameter("no").trim());

		TotalDAO dao = TotalDAO.getInstance();

		SellBoardDTO cont = dao.getSellBoardContent(board_no);

		AdminDTO dealer = dao.getDealerInfo(cont.getSell_board_admin_no());

		CompanyDTO cops = dao.getCompanyInfo();

		List<String> cardList = StaticArea.getCardCops();

		int carPrice = cont.getSell_board_car_price() * 10000;

		request.setAttribute("cont", cont);
		request.setAttribute("dealer", dealer);
		request.setAttribute("cops", cops);
		request.setAttribute("cardList", cardList);
		request.setAttribute("carPrice", carPrice);

		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/public/search/car_list_content.jsp");

		return forward;
	}

}
