package com.car.action.boards;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.car.action.Action;
import com.car.action.ActionForward;
import com.car.model.BuyReviewBoardDTO;
import com.car.model.TotalDAO;

public class BuyReviewBoardSearchAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) {

		TotalDAO dao = TotalDAO.getInstance();

		int cnt = 0;

		int buyreview_rowsize = 10;

		int buyreview_block = 3;

		int buyreview_allPage = 0;

		int buyreview_page = 1;

		if (request.getParameter("buyreview_page") != null) {

			buyreview_page = Integer.parseInt(request.getParameter("buyreview_page").trim());

			if (buyreview_page < 1) {
				buyreview_page = 1;

			}

		}

		int buyreview_startNo = (buyreview_page * buyreview_rowsize) - (buyreview_rowsize - 1);

		int buyreview_endNo = buyreview_page * buyreview_rowsize;

		int buyreview_startBlock = (((buyreview_page - 1) / buyreview_block) * buyreview_block) + 1;

		int buyreview_endBlock = (((buyreview_page - 1) / buyreview_block) * buyreview_block) + buyreview_block;

		String buyreview_field = request.getParameter("field").trim();

		String buyreview_keyword = request.getParameter("keyword").trim();

		cnt = dao.countBuyReviewBoardSearchList(buyreview_field, buyreview_keyword);

		buyreview_allPage = (int) Math.ceil(cnt / (double) buyreview_rowsize);

		if (buyreview_endBlock > buyreview_allPage) {
			buyreview_endBlock = buyreview_allPage;
		}

		boolean is_cSearch = true;

		List<BuyReviewBoardDTO> list = dao.searchBuyReviewBoardList(buyreview_field, buyreview_keyword, buyreview_page,
				buyreview_rowsize);

		System.out.println(list.get(0).getBuy_review_board_title());

		request.setAttribute("buy_review_list", list);
		request.setAttribute("cnt", cnt);
		request.setAttribute("buyreview_rowsize", buyreview_rowsize);
		request.setAttribute("buyreview_block", buyreview_block);
		request.setAttribute("buyreview_allPage", buyreview_allPage);
		request.setAttribute("buyreview_page", buyreview_page);
		request.setAttribute("buyreview_startNo", buyreview_startNo);
		request.setAttribute("buyreview_endNo", buyreview_endNo);
		request.setAttribute("buyreview_startBlock", buyreview_startBlock);
		request.setAttribute("buyreview_endBlock", buyreview_endBlock);
		request.setAttribute("buyreview_field", buyreview_field);
		request.setAttribute("buyreview_keyword", buyreview_keyword);
		request.setAttribute("is_cSearch", is_cSearch);

		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/public/boards/buy_review_board_list.jsp");

		return forward;

	}

}
